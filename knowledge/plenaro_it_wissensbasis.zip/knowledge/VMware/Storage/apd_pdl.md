# VMware APD / PDL Storage Problem

## Symptom

Datastore oder LUN ist nicht erreichbar; VMs hängen oder I/O stoppt.

## Bedeutung

APD bedeutet All Paths Down ohne definitive Geräteentfernung; PDL bedeutet dauerhaft nicht verfügbares Gerät.

## Typische Ursachen

- SAN-Pfadverlust
- Array/LUN entfernt
- Fabric/Netzproblem
- iSCSI/NFS-Pfad gestört

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
esxcli storage core path list
esxcli storage core device list
vmkping für iSCSI/NFS-Netze
tail -n 100 /var/log/vmkernel.log
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Storage-Pfade und Backend zuerst wiederherstellen.
- LUN nicht vorschnell resignaturen/manuell entfernen.
- Bei PDL geplante Storage-Entfernung gegen Konfiguration abgleichen.

## Weiterführende Prüfung

- Multipath-Policy prüfen.
- SAN-/Switch-/Array-Events korrelieren.
