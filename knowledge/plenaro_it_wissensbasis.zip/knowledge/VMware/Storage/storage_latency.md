# VMware Storage-Latenz hoch

## Symptom

VMs reagieren langsam; vCenter zeigt hohe Datastore-/Disk-Latenzen.

## Bedeutung

I/O-Wartezeiten entstehen im Guest, ESXi-Stack, HBA/Netz oder Storage-Backend.

## Typische Ursachen

- Storage überlastet
- Queueing
- Pfadproblem
- Snapshot-Kette
- Guest-I/O-Spitze

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
esxtop (Disk-Ansicht)
vCenter Performance Charts
esxcli storage core path list
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Latenz auf Guest, Host und Array korrelieren.
- Pfadstatus und Multipathing prüfen.
- Snapshot-Ketten und hohe I/O-Last identifizieren.
- Storage-Team mit Zeitstempel und betroffenen LUNs/Datastores einbeziehen.

## Weiterführende Prüfung

- GAVG/KAVG/DAVG in esxtop fachgerecht interpretieren.
- Nicht nur CPU Ready betrachten.
