# VMware Snapshot: Quiesce fehlgeschlagen

## Symptom

Backup oder Snapshot mit Quiescing schlägt fehl.

## Bedeutung

VMware Tools/VSS bzw. Gastdateisystem kann keinen konsistenten Quiesce-Zustand herstellen.

## Typische Ursachen

- VMware Tools Problem
- Windows VSS Writer fehlerhaft
- Guest stark ausgelastet
- Unsupported workload

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
VMware Tools Status in vCenter
vssadmin list writers (Windows Guest)
journalctl für Linux-Anwendungsdienste nach Bedarf
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- VMware Tools prüfen/aktualisieren.
- Bei Windows VSS Writer Status reparieren.
- Backupsoftware und anwendungskonsistente Einstellungen prüfen.
- Nicht dauerhaft Quiescing abschalten, wenn Applikationskonsistenz erforderlich ist.

## Weiterführende Prüfung

- Snapshot ohne Quiesce nur als Diagnose nutzen.
- Datenbank-spezifische Backupanforderungen beachten.
