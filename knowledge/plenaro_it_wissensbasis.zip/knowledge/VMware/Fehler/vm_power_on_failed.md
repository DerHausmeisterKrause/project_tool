# VMware VM lässt sich nicht einschalten

## Symptom

Power On schlägt mit Task-Fehler fehl.

## Bedeutung

Häufig fehlen Ressourcen, Dateien sind gesperrt oder Konfiguration/Storage ist nicht verfügbar.

## Typische Ursachen

- Datastore voll
- VMDK-Lock
- Hostressourcen
- Datei fehlt
- HA Admission Control

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
vCenter Task Details
Datastore Browser
ESXi vmware.log/hostd.log
vCenter Resource Usage
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exakte Taskmeldung auswerten.
- Datastoreplatz und Dateiverfügbarkeit prüfen.
- Locks nur nach eindeutiger Eigentümeranalyse behandeln.
- Ressourcen-/HA-Konfiguration prüfen.

## Weiterführende Prüfung

- Nicht einfach VM-Dateien kopieren/löschen.
- Bei Shared Storage andere Hosts als Lock-Owner berücksichtigen.
