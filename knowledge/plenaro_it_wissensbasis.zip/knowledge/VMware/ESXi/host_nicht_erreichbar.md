# ESXi Host nicht erreichbar

## Symptom

vCenter oder Browser kann ESXi-Host nicht erreichen.

## Bedeutung

Management-Netzwerk, Hostdienste oder physische Konnektivität ist gestört.

## Typische Ursachen

- Management vmkernel offline
- VLAN falsch
- vmnic down
- hostd/vpxa Problem

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
vmkping <gateway>
esxcli network ip interface list
esxcli network nic list
/etc/init.d/hostd status
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Management-Netzwerk und vmkernel prüfen.
- Uplink/VLAN kontrollieren.
- hostd nur bei Bedarf neu starten; laufende VMs werden dadurch nicht ausgeschaltet, Management kann aber kurz weg sein.

## Weiterführende Prüfung

- DCUI für Management Network Test verwenden.
- vCenter-Verbindung getrennt von Host-Erreichbarkeit prüfen.
