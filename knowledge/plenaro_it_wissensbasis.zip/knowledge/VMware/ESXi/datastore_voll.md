# ESXi Datastore fast oder vollständig voll

## Symptom

VMs können nicht wachsen, Snapshots scheitern oder VMs pausieren.

## Bedeutung

Datastore hat zu wenig freien Speicher für VMDKs, Snapshots oder Swap-Dateien.

## Typische Ursachen

- Alte Snapshots
- ISOs/Logs
- Thin Provisioning Wachstum
- Orphaned files

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
esxcli storage filesystem list
du nur mit Vorsicht über ESXi-Shell in konkreten Datastore-Verzeichnissen
vCenter Datastore Browser
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Freien Platz schaffen, aber keine VMDK-/Snapshotdateien manuell löschen.
- Snapshots über Snapshot Manager konsolidieren/löschen.
- ISO/Logs/orphaned Dateien nur nach eindeutiger Zuordnung entfernen.

## Weiterführende Prüfung

- Thin Provisioning und Storage-Backend-Kapazität prüfen.
- Alarmgrenzen konfigurieren.
