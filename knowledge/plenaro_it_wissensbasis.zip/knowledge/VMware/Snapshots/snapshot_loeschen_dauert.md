# VMware Snapshot-Löschung dauert sehr lange

## Symptom

Snapshot Delete/Consolidate läuft lange und Datastore-I/O steigt.

## Bedeutung

Delta-VMDKs müssen in Basisscheiben zusammengeführt werden; große/alte Snapshots verursachen viel I/O.

## Typische Ursachen

- Sehr großer Snapshot
- Hohe VM-I/O-Last
- Langsamer Datastore
- Mehrstufige Snapshot-Kette

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
vim-cmd vmsvc/getallvms
vim-cmd vmsvc/snapshot.get <vmid>
Datastore Performance Charts
VM-Verzeichnis im Datastore Browser kontrollieren
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Task nicht durch Hostneustart erzwingen.
- I/O-Last beobachten.
- Ausreichend freien Datastore-Speicher sicherstellen.
- Bei Problemen VMware-Dokumentation/Supportpfad für Consolidation nutzen.

## Weiterführende Prüfung

- Snapshot-Alarme setzen.
- Snapshots nicht als Backup-Ersatz nutzen.
