# Virtual machine disks consolidation is needed

## Symptom

vCenter meldet, dass virtuelle Festplatten konsolidiert werden müssen.

## Bedeutung

Snapshot-Metadaten und Delta-Dateien sind nach Backup-/Snapshotvorgängen nicht vollständig zusammengeführt.

## Typische Ursachen

- Backupjob abgebrochen
- Snapshot Delete unvollständig
- Storageproblem
- Lock

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
vCenter Snapshot Manager
Datastore Browser
VM Events/Tasks
ESXi vmware.log der VM
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Vorhandene Backups und freien Platz prüfen.
- `Consolidate` über vCenter ausführen.
- Bei Fehlschlag Locks, Storage und Backupsoftware prüfen.
- Keine Snapshotdateien manuell löschen.

## Weiterführende Prüfung

- Backup-Software auf hängen gebliebene Snapshotjobs prüfen.
- Wiederkehrende Ursache beheben.
