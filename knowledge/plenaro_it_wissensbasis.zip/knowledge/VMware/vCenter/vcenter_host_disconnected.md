# vCenter: Host Disconnected

## Symptom

ESXi Host erscheint in vCenter als Disconnected oder Not Responding.

## Bedeutung

Managementpfad zwischen vCenter und ESXi oder vpxa/hostd ist gestört.

## Typische Ursachen

- DNS/Netzwerk
- Zertifikat/Management Agent
- vCenter IP geändert
- Host überlastet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ping <esxi>
nslookup <esxi>
Test-NetConnection <esxi> -Port 443
Test-NetConnection <esxi> -Port 902
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- DNS und Managementports prüfen.
- Direkten ESXi-Webzugriff testen.
- Reconnect in vCenter versuchen.
- Management Agents nur gezielt und mit Kenntnis der Umgebung neu starten.

## Weiterführende Prüfung

- Firewall zwischen vCenter und Hosts prüfen.
- Zeit/NTP und Zertifikate kontrollieren.
