# vCenter Task hängt

## Symptom

Ein vCenter-Task bleibt lange bei einem Prozentwert oder 'In Progress'.

## Bedeutung

Backend-Operation, Hostkommunikation oder Storage reagiert nicht wie erwartet.

## Typische Ursachen

- Storage-Latenz
- Host nicht erreichbar
- vCenter-Serviceproblem
- Lock auf VM

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
tail -n 100 /var/log/vmware/vpxd/vpxd.log
tail -n 100 /var/log/vmkernel.log
tail -n 100 /var/log/hostd.log
service-control --status --all
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Betroffene VM/Host/Datastore eingrenzen.
- Nicht denselben Task mehrfach starten.
- Storage-/Hostfehler zuerst beheben.
- Task-Abbruch nur verwenden, wenn die Operation sicher abgebrochen werden kann.

## Weiterführende Prüfung

- VM-Dateilocks prüfen, wenn Power-/Snapshot-Operation betroffen ist.
- vCenter-Logs bei wiederkehrendem Problem auswerten.
