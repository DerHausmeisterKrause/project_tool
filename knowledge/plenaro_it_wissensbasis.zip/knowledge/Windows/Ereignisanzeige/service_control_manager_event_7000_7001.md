# Event ID 7000/7001 – Dienststartfehler

## Symptom

Im Systemlog erscheinen Service Control Manager Events 7000 oder 7001.

## Bedeutung

Ein Dienst konnte nicht starten oder eine Abhängigkeit ist fehlgeschlagen.

## Typische Ursachen

- Dienstdatei fehlt
- Dienstkonto fehlerhaft
- Abhängigkeit nicht gestartet
- Treiber-/Service-Konfiguration veraltet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Get-WinEvent -FilterHashtable @{LogName='System'; Id=7000,7001} -MaxEvents 50
sc qc <dienstname>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exakten Dienstnamen und Ereignistext auswerten.
- Pfad, Konto und Abhängigkeiten prüfen.
- Verwaiste Dienste nach Software-Deinstallation nur nach eindeutiger Zuordnung entfernen.

## Weiterführende Prüfung

- Weitere SCM-Events 7009, 7011, 7023 und 7031 im selben Zeitraum prüfen.
