# Event ID 1000 – Application Error

## Symptom

Eine Anwendung stürzt ab und Event ID 1000 erscheint im Application-Log.

## Bedeutung

Windows protokolliert einen Anwendungsabsturz inklusive fehlerhafter Anwendung und fehlerhaftem Modul.

## Typische Ursachen

- Bug in Anwendung
- Defekte DLL
- Inkompatibles Plugin
- Beschädigte Laufzeitbibliothek oder Anwendung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1000} -MaxEvents 20
wevtutil qe Application /q:"*[System[(EventID=1000)]]" /c:10 /f:text
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Faulting application/module und Exception Code aus Event auslesen.
- Anwendung aktualisieren oder reparieren.
- Plugins/Erweiterungen isoliert deaktivieren.
- Bei System-DLLs SFC/DISM prüfen.

## Weiterführende Prüfung

- Parallel auftretende Windows Error Reporting Events prüfen.
- Crashdump analysieren, wenn der Fehler reproduzierbar und kritisch ist.
