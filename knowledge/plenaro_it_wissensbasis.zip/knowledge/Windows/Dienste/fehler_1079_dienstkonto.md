# Fehler 1079 – Dienstkonto stimmt nicht mit Abhängigkeiten überein

## Symptom

Dienststart schlägt mit Fehler 1079 fehl.

## Bedeutung

Der Dienst ist mit einem unpassenden Konto konfiguriert, häufig im Vergleich zu Diensten derselben svchost-Gruppe.

## Typische Ursachen

- Dienstkonto manuell verändert
- Fehlerhafte Härtung
- Registry-/Service-Konfiguration verändert

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sc qc <dienstname>
Get-CimInstance Win32_Service -Filter "Name='<dienstname>'" | Select Name,StartName,State
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Dienstkonto anhand Microsoft-/Herstellerstandard korrigieren.
- Kennwort bei benutzerdefinierten Dienstkonten prüfen.
- Dienst neu starten und Systemlog kontrollieren.

## Weiterführende Prüfung

- Vor Änderung bestehende Service-Konfiguration dokumentieren.
- Gruppenrichtlinien für Systemdienste prüfen.
