# Fehler 1068 – Abhängiger Dienst konnte nicht gestartet werden

## Symptom

Ein Dienst startet nicht und meldet Fehler 1068.

## Bedeutung

Mindestens ein konfigurierter Abhängigkeitsdienst ist gestoppt oder fehlerhaft.

## Typische Ursachen

- Abhängiger Dienst deaktiviert
- Abhängigkeit selbst fehlerhaft
- Dienstkonto-/Berechtigungsproblem
- Konfigurationsänderung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sc qc <dienstname>
sc query <abhaengigkeitsdienst>
Get-Service <dienstname> -RequiredServices
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Abhängigkeiten identifizieren.
- Zuerst den fehlerhaften Abhängigkeitsdienst reparieren und starten.
- Starttyp und Dienstkonto prüfen.
- Danach Zieldienst erneut starten.

## Weiterführende Prüfung

- Systemlog nach Service Control Manager-Ereignissen durchsuchen.
- Keine Abhängigkeit ohne Herstellerdokumentation entfernen.
