# Fehler 1053 – Dienst antwortet nicht rechtzeitig

## Symptom

Beim Start eines Windows-Dienstes erscheint Fehler 1053.

## Bedeutung

Der Service Control Manager erhält nicht rechtzeitig die erwartete Rückmeldung des Dienstes.

## Typische Ursachen

- Anwendung hängt beim Start
- Abhängigkeit oder Netzwerkressource nicht erreichbar
- Defekte Konfiguration
- Unzureichende Rechte des Dienstkontos

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sc query <dienstname>
sc qc <dienstname>
Get-Service -Name <dienstname>
Get-WinEvent -LogName System -MaxEvents 100
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Anwendungslog und Systemlog prüfen.
- Dienstabhängigkeiten und Dienstkonto testen.
- Konfigurationsfehler beheben.
- Timeout nur erhöhen, wenn der Dienst technisch korrekt arbeitet und nachweislich mehr Startzeit benötigt.

## Weiterführende Prüfung

- Event IDs des Service Control Managers und anwendungsspezifische Logs korrelieren.
- Start des Programms interaktiv nur zu Diagnosezwecken testen, falls unterstützt.
