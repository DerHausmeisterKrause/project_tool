# RDP NLA-Anmeldefehler

## Symptom

RDP erreicht den Host, Anmeldung schlägt jedoch vor dem Sitzungsaufbau fehl.

## Bedeutung

Network Level Authentication kann wegen Kennwort, Domänenkontakt, Uhrzeit oder CredSSP-Problemen scheitern.

## Typische Ursachen

- Falsche Anmeldedaten
- Domänencontroller nicht erreichbar
- Zeitabweichung
- CredSSP-/Patchstand-Inkompatibilität

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
w32tm /query /status
nltest /dsgetdc:<domain>
Test-ComputerSecureChannel -Verbose
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Anmeldedaten und Domänenpräfix prüfen.
- Zeit synchronisieren.
- DC-Erreichbarkeit und Secure Channel prüfen.
- Beide Systeme auf unterstützten Patchstand bringen.

## Weiterführende Prüfung

- Security-Log nach fehlgeschlagenen Logons prüfen.
- CredSSP-Workarounds nicht dauerhaft auf unsichere Werte setzen.
