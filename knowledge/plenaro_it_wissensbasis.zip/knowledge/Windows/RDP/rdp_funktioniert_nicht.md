# RDP-Verbindung funktioniert nicht

## Symptom

Remote Desktop verbindet nicht, obwohl der Server/Client grundsätzlich erreichbar ist.

## Bedeutung

RDP kann deaktiviert, durch Firewall blockiert oder der Dienst kann gestört sein.

## Typische Ursachen

- RDP deaktiviert
- TCP 3389 blockiert
- TermService gestoppt
- NLA-/Authentifizierungsproblem
- Falscher Zielhost

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Test-NetConnection <server> -Port 3389
Get-Service TermService
qwinsta
netstat -ano | findstr :3389
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Netzwerkerreichbarkeit und Port 3389 prüfen.
- Remote Desktop und passende Firewallregel aktivieren.
- TermService-Status prüfen.
- NLA nur gezielt und nicht dauerhaft als Workaround deaktivieren.

## Weiterführende Prüfung

- RemoteDesktopServices- und TerminalServices-Logs prüfen.
- Bei RD Gateway zusätzlich HTTPS-/Gateway-Konnektivität prüfen.
