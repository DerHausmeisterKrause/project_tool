# Schwarzer Bildschirm nach Windows-Anmeldung

## Symptom

Anmeldung ist erfolgreich, danach bleibt der Bildschirm schwarz oder nur der Mauszeiger ist sichtbar.

## Bedeutung

Explorer, Grafiktreiber oder ein Autostart-/Shell-Prozess startet nicht korrekt.

## Typische Ursachen

- explorer.exe nicht gestartet
- Defekter Grafiktreiber
- Fehlerhafte Shell-Konfiguration
- Beschädigte Systemdateien

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
tasklist | findstr /i explorer.exe
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit Strg+Shift+Esc den Task-Manager öffnen und explorer.exe manuell starten.
- Wenn das hilft, Autostarts und Shell-Konfiguration prüfen.
- Grafiktreiber aktualisieren oder auf stabile Version zurücksetzen.
- SFC und DISM nur in administrativer Eingabeaufforderung ausführen.

## Weiterführende Prüfung

- Abgesicherten Modus testen.
- Ereignisanzeige auf Explorer-, Shell- und Grafiktreiberfehler prüfen.
