# Temporäres Benutzerprofil unter Windows

## Symptom

Nach der Anmeldung erscheint ein temporäres Profil. Desktop, Einstellungen oder Dateien des normalen Profils fehlen.

## Bedeutung

Windows konnte das reguläre Benutzerprofil nicht korrekt laden und verwendet ein temporäres Profil.

## Typische Ursachen

- Beschädigtes Benutzerprofil
- Fehlerhafter Eintrag unter ProfileList
- Datenträger- oder Dateisystemfehler
- Fehlende Berechtigungen auf dem Profilordner

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
whoami
echo %USERPROFILE%
chkdsk C: /scan
sfc /scannow
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Zuerst Benutzerdateien sichern.
- Ereignisanzeige unter Windows-Protokolle > Anwendung auf User Profile Service prüfen.
- Beschädigte Profile nicht blind löschen; bei Bedarf neues Profil anlegen und Benutzerdaten kontrolliert übernehmen.
- Bei Dateisystemfehlern zuerst diese beheben.

## Weiterführende Prüfung

- Prüfen, ob der Fehler nur einen Benutzer oder mehrere Benutzer betrifft.
- Freien Speicherplatz auf C: prüfen.
- Antivirus/EDR-Blockierungen und NTFS-Rechte kontrollieren.
