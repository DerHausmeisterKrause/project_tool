# DNS-Auflösung unter Windows funktioniert nicht

## Symptom

Hostnamen können nicht aufgelöst werden, IP-Verbindungen funktionieren aber.

## Bedeutung

Der Client erreicht keinen geeigneten DNS-Server oder erhält falsche/fehlende Antworten.

## Typische Ursachen

- Falscher DNS-Server
- VPN-/Adapterpriorität
- DNS-Server nicht erreichbar
- Fehlerhafte DNS-Einträge
- Lokaler Cache

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ipconfig /all
nslookup example.org
Resolve-DnsName example.org
ipconfig /flushdns
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Konfigurierte DNS-Server prüfen.
- Abfrage gezielt gegen erwarteten DNS-Server testen.
- DNS-Cache leeren, wenn alte Einträge vermutet werden.
- In AD-Umgebungen interne Clients nicht auf öffentliche DNS-Server konfigurieren.

## Weiterführende Prüfung

- Suffix-Suchliste prüfen.
- Firewall-Regeln für UDP/TCP 53 kontrollieren.
