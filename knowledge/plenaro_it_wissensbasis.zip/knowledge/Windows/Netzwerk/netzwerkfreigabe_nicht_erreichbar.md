# Windows-Netzwerkfreigabe nicht erreichbar

## Symptom

Pfad wie \\server\share öffnet nicht oder meldet Netzwerkfehler.

## Bedeutung

Namensauflösung, SMB-Konnektivität, Freigabe-/NTFS-Rechte oder Serverdienst sind gestört.

## Typische Ursachen

- DNS-Problem
- TCP 445 blockiert
- Server offline
- Freigabe existiert nicht
- Berechtigungen fehlen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nslookup <server>
Test-NetConnection <server> -Port 445
net view \\<server>
Get-SmbConnection
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Erreichbarkeit per DNS und TCP 445 prüfen.
- Freigabename kontrollieren.
- Freigabe- und NTFS-Rechte getrennt prüfen.
- Gespeicherte falsche Anmeldeinformationen in der Anmeldeinformationsverwaltung entfernen.

## Weiterführende Prüfung

- Zugriff testweise per FQDN prüfen.
- SMB-Serverlogs und Security-Events prüfen.
