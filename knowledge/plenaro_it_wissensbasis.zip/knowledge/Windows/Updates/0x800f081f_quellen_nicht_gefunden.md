# 0x800f081f – Quelldateien nicht gefunden

## Symptom

DISM, .NET-Featureinstallation oder Windows Update meldet 0x800f081f.

## Bedeutung

Windows findet die benötigten Komponentenquelldateien nicht im lokalen Store oder über die konfigurierte Quelle.

## Typische Ursachen

- Komponentenstore beschädigt
- WSUS liefert Reparaturinhalte nicht
- Installationsmedium passt nicht zur Windows-Version
- Source-Pfad falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
DISM /Online /Cleanup-Image /ScanHealth
DISM /Online /Get-CurrentEdition
winver
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Passende Installationsquelle derselben Version/Edition/Build verwenden.
- DISM mit korrekter /Source-Quelle ausführen.
- Bei verwalteten Umgebungen Richtlinie für optionale Komponenten und Reparaturinhalte prüfen.

## Weiterführende Prüfung

- CBS.log und DISM.log auswerten.
- Nicht mit einem beliebigen ISO anderer Build-Version reparieren.
