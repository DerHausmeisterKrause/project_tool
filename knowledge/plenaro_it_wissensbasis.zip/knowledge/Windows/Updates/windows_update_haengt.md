# Windows Update hängt

## Symptom

Update-Suche, Download oder Installation bleibt über lange Zeit bei einem Prozentwert stehen.

## Bedeutung

Update-Komponenten, Netzwerkzugriff, Komponentenstore oder ein ausstehender Neustart blockieren den Ablauf.

## Typische Ursachen

- WSUS/Proxy nicht erreichbar
- Beschädigter Komponentenstore
- Pending Reboot
- Update-Cache inkonsistent

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Get-Service wuauserv,bits,cryptsvc
DISM /Online /Cleanup-Image /ScanHealth
sfc /scannow
Get-WindowsUpdateLog
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Zuerst Neustart und freien Speicher prüfen.
- WSUS/Proxy-Erreichbarkeit kontrollieren.
- Komponentenstore mit DISM reparieren.
- Update-Cache nur gezielt zurücksetzen, wenn Logs auf Cache-Probleme hinweisen.

## Weiterführende Prüfung

- CBS.log und WindowsUpdate.log analysieren.
- Fehlercode des konkreten Updates dokumentieren.
