# gpupdate schlägt wegen SYSVOL-Zugriff fehl

## Symptom

gpupdate meldet, dass Gruppenrichtlinien nicht verarbeitet werden konnten oder Dateien unter SYSVOL nicht erreichbar sind.

## Bedeutung

Der Client kann die Richtliniendateien auf dem Domänencontroller nicht lesen.

## Typische Ursachen

- DNS zeigt auf falschen Resolver
- SMB/445 blockiert
- SYSVOL nicht freigegeben
- DFSR-/Replikationsfehler

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
echo %LOGONSERVER%
dir \\%LOGONSERVER%\SYSVOL
Test-NetConnection <dc> -Port 445
nslookup <domain.local>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Client-DNS auf interne AD-DNS-Server korrigieren.
- SMB zwischen Client und DC zulassen.
- SYSVOL/NETLOGON-Freigaben am DC prüfen.
- Bei Replikationsproblemen DFSR/AD-Replikation reparieren.

## Weiterführende Prüfung

- dcdiag auf Domänencontrollern ausführen.
- repadmin /replsummary zur Replikationsübersicht verwenden.
