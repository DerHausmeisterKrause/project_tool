# GPO wird nicht angewendet

## Symptom

Eine erwartete Gruppenrichtlinie greift auf Benutzer oder Computer nicht.

## Bedeutung

Die GPO ist nicht im wirksamen Pfad, wird gefiltert, nicht repliziert oder kann wegen DNS/AD-Problemen nicht verarbeitet werden.

## Typische Ursachen

- Security Filtering
- WMI-Filter
- Falsche OU-Verknüpfung
- Block Inheritance/Enforced
- SYSVOL- oder DNS-Probleme

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
gpupdate /force
gpresult /h C:\Temp\gpresult.html
gpresult /r
rsop.msc
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit gpresult prüfen, ob die GPO gelistet oder herausgefiltert wird.
- OU-Link, Security Filtering und WMI-Filter kontrollieren.
- DNS muss auf AD-DNS zeigen.
- SYSVOL/NETLOGON-Erreichbarkeit prüfen.

## Weiterführende Prüfung

- Event Viewer: Microsoft-Windows-GroupPolicy/Operational prüfen.
- Bei mehreren DCs Replikation prüfen.
