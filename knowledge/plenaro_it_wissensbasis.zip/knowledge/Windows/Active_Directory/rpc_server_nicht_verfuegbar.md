# RPC-Server nicht verfügbar

## Symptom

AD-Verwaltung, Remoteverwaltung oder MMC-Snap-ins melden, dass der RPC-Server nicht verfügbar ist.

## Bedeutung

Der Zielhost ist nicht erreichbar oder RPC-Endpunktmapper/dynamische RPC-Ports werden blockiert.

## Typische Ursachen

- DNS-Auflösung fehlerhaft
- TCP 135 oder dynamische RPC-Ports blockiert
- Dienst nicht erreichbar
- Host-Firewall oder Netzsegmentierung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nslookup <server>
ping <server>
Test-NetConnection <server> -Port 135
sc query RpcSs
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- DNS zuerst korrigieren.
- TCP 135 und erforderliche dynamische RPC-Ports zwischen den beteiligten Systemen freigeben.
- RPC-Dienst nicht deaktivieren.
- Firewalls beidseitig prüfen.

## Weiterführende Prüfung

- Ereignisanzeige auf DCOM/RPC-Fehler prüfen.
- Bei AD zusätzlich Replikations- und Zeitprobleme ausschließen.
