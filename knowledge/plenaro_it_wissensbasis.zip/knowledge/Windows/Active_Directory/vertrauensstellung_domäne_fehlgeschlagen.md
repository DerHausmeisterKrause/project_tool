# Vertrauensstellung zwischen Workstation und Domäne fehlgeschlagen

## Symptom

Bei der Anmeldung erscheint, dass die Vertrauensstellung zwischen dieser Arbeitsstation und der primären Domäne fehlgeschlagen ist.

## Bedeutung

Das Computerkontokennwort auf Client und Active Directory stimmt nicht mehr überein.

## Typische Ursachen

- VM-Snapshot/Rollback
- Lange Offline-Zeit
- Zurückgesetztes oder dupliziertes Computerkonto
- Fehlerhafte Wiederherstellung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Test-ComputerSecureChannel -Verbose
Test-ComputerSecureChannel -Repair -Credential (Get-Credential)
nltest /sc_verify:DOMAIN.LOCAL
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit lokalem Administratorkonto anmelden.
- Secure Channel mit PowerShell reparieren oder Computer kontrolliert aus der Domäne entfernen und erneut hinzufügen.
- Vor Rejoin sicherstellen, dass DNS auf interne AD-DNS-Server zeigt.

## Weiterführende Prüfung

- AD-Computerkonto auf Duplikate prüfen.
- Zeitabweichung und DNS-Konfiguration kontrollieren.
