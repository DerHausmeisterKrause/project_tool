# 0x80070643 – Installationsfehler

## Symptom

Windows Update oder MSI-basierte Installation meldet 0x80070643.

## Bedeutung

Der Windows Installer bzw. ein Updatepaket konnte die Installation nicht erfolgreich abschließen.

## Typische Ursachen

- MSI-/Custom-Action-Fehler
- Beschädigte Installationsquelle
- Fehlender Neustart
- Komponenten-/ .NET-Problem

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
msiexec /?
sfc /scannow
DISM /Online /Cleanup-Image /ScanHealth
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Bei MSI ein ausführliches Installationslog erzeugen: msiexec /i paket.msi /L*v C:\Temp\install.log
- Konkreten Return Value/Custom Action im Log auswerten.
- Komponentenstore reparieren, wenn Systemkomponenten betroffen sind.

## Weiterführende Prüfung

- Windows Update-Historie und CBS.log prüfen.
- Nicht jeden 0x80070643 mit derselben Pauschallösung behandeln.
