# 0x80070035 – Netzwerkpfad nicht gefunden

## Symptom

Zugriff auf \\server\share schlägt mit 0x80070035 fehl.

## Bedeutung

Windows kann Zielname, SMB-Dienst oder Freigabe nicht erreichen.

## Typische Ursachen

- DNS-/Namensauflösung
- TCP 445 blockiert
- Server/Freigabe nicht verfügbar
- SMB-Komponente/Firewall

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nslookup <server>
Test-NetConnection <server> -Port 445
net view \\<server>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Namensauflösung und TCP 445 prüfen.
- Freigabename validieren.
- Serverdienst/Firewall und SMB-Konfiguration kontrollieren.

## Weiterführende Prüfung

- Zugriff per FQDN und testweise per IP zur Eingrenzung vergleichen.
- Bei AD keine dauerhafte Lösung über IP erzwingen.
