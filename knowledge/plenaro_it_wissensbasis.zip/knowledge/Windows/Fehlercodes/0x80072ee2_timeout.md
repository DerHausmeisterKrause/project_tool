# 0x80072ee2 – Timeout

## Symptom

Windows Update oder eine Microsoft-Komponente meldet 0x80072ee2.

## Bedeutung

Eine HTTP/HTTPS-Verbindung zum benötigten Dienst läuft in ein Zeitlimit.

## Typische Ursachen

- Proxy/Firewall
- WSUS nicht erreichbar
- DNS-Probleme
- Instabile Verbindung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
netsh winhttp show proxy
nslookup <zielhost>
Test-NetConnection <zielhost> -Port 443
curl.exe -I https://<zielhost>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Proxy-Konfiguration und DNS prüfen.
- Firewall-/Webfilter-Freigaben kontrollieren.
- Bei WSUS Erreichbarkeit des internen Servers prüfen.

## Weiterführende Prüfung

- Zeitstempel in WindowsUpdate.log und Proxy-/Firewall-Logs korrelieren.
- TLS-Inspection berücksichtigen.
