# 0x80070005 – Zugriff verweigert

## Symptom

Eine Installation, Dateioperation oder Windows-Komponente meldet 0x80070005.

## Bedeutung

Die angeforderte Aktion scheitert an fehlenden Berechtigungen oder Sicherheitsrichtlinien.

## Typische Ursachen

- Fehlende NTFS-/Registry-Rechte
- Prozess nicht erhöht gestartet
- Dienstkonto ohne Rechte
- Security-Software blockiert

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
whoami /groups
icacls <pfad>
Get-Acl <pfad> | Format-List
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit dem tatsächlich benötigten Konto und minimal erforderlichen Rechten arbeiten.
- NTFS-/Registry-Berechtigungen gezielt korrigieren.
- Anwendung bei Bedarf erhöht starten.
- Security-Logs und EDR-Ereignisse prüfen.

## Weiterführende Prüfung

- Nicht pauschal Everyone/Vollzugriff setzen.
- Prüfen, ob der Fehler auf Datei, Registry, COM/DCOM oder Dienstkonto bezogen ist.
