# 0x80070002 – Datei nicht gefunden

## Symptom

Windows Update, Setup oder Skript meldet 0x80070002.

## Bedeutung

Eine erwartete Datei oder ein Pfad ist nicht vorhanden bzw. der Updatezustand ist inkonsistent.

## Typische Ursachen

- Falscher Pfad
- Fehlende Setup-Datei
- Beschädigter Update-Cache
- Datei durch AV/EDR entfernt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
dir <pfad>
where <datei>
sfc /scannow
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Im Fehlerkontext den tatsächlich fehlenden Pfad ermitteln.
- Setup-/Paketquelle validieren.
- Bei Windows Update Komponentenstore und Update-Logs prüfen.

## Weiterführende Prüfung

- Nicht nur anhand des Codes den Update-Cache löschen.
- ProcMon kann bei schwer auffindbaren Pfadfehlern helfen.
