# Server Manager startet nicht

## Symptom

Server Manager öffnet nicht, schließt sofort oder zeigt Initialisierungsfehler.

## Bedeutung

Die Verwaltungsoberfläche kann wegen beschädigter Komponenten, PowerShell-/WMI-Problemen oder fehlenden Systemdateien ausfallen.

## Typische Ursachen

- Beschädigte Windows-Komponenten
- WMI-/CIM-Probleme
- Fehlerhafte .NET-/PowerShell-Komponenten
- Profilbezogener Cachefehler

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sfc /scannow
DISM /Online /Cleanup-Image /ScanHealth
DISM /Online /Cleanup-Image /RestoreHealth
Get-WindowsFeature
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Systemdateien mit SFC und DISM prüfen.
- Test mit einem administrativen Benutzerkonto durchführen.
- PowerShell und Ereignisanzeige verwenden, um die eigentliche Rollen-/Feature-Verwaltung weiterzuführen.

## Weiterführende Prüfung

- Application- und Microsoft-Windows-ServerManager-Protokolle prüfen.
- Bei WMI-Verdacht CIM-Abfragen testen.
