# Windows Server Rolle oder Feature lässt sich nicht installieren

## Symptom

Add Roles and Features Wizard oder Install-WindowsFeature schlägt fehl.

## Bedeutung

Quellen, Komponentenstore, Abhängigkeiten oder ausstehende Wartungsaktionen verhindern die Installation.

## Typische Ursachen

- Beschädigter Komponentenstore
- Fehlende Quelldateien
- Neustart ausstehend
- WSUS/GPO verhindert Download von Reparaturinhalten

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Get-WindowsFeature
DISM /Online /Cleanup-Image /ScanHealth
DISM /Online /Cleanup-Image /RestoreHealth
Get-WindowsUpdateLog
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Fehlercode aus Wizard/PowerShell notieren.
- Komponentenstore reparieren.
- Bei fehlenden Quellen passenden Installationsdatenträger derselben Windows-Version verwenden.
- Erforderlichen Neustart durchführen.

## Weiterführende Prüfung

- CBS.log unter C:\Windows\Logs\CBS prüfen.
- Gruppenrichtlinien für optionale Komponenten und Reparaturinhalte prüfen.
