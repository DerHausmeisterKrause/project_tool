# Druckauftrag bleibt in Warteschlange hängen

## Symptom

Dokumente bleiben auf 'Wird gedruckt' oder 'Fehler' und blockieren weitere Jobs.

## Bedeutung

Spooler, Druckertreiber, Port oder Zielgerät verarbeitet den Auftrag nicht.

## Typische Ursachen

- Spooler hängt
- Defekter Druckjob
- Treiberproblem
- Drucker/Printserver offline

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Get-Service Spooler
Get-Printer
Get-PrintJob -PrinterName '<drucker>'
Test-NetConnection <printserver> -Port 445
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Spooler stoppen, blockierende Jobs kontrolliert entfernen und Spooler wieder starten.
- Treiber und Port prüfen.
- Bei Netzwerkdruckern Erreichbarkeit des Printservers/Druckers testen.

## Weiterführende Prüfung

- Microsoft-Windows-PrintService/Operational aktivieren und prüfen.
- Treiberisolation und Printserver-Ereignisse kontrollieren.
