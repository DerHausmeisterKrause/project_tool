# Print Spooler startet nicht

## Symptom

Der Dienst 'Druckwarteschlange' beendet sich sofort oder lässt sich nicht starten.

## Bedeutung

Meist blockiert ein defekter Treiber, Print Processor oder beschädigter Spool-Inhalt den Dienst.

## Typische Ursachen

- Defekter Druckertreiber
- Fehlerhafter Print Processor
- Beschädigte Spool-Datei
- Abhängigkeit fehlerhaft

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sc query Spooler
sc qc Spooler
Get-WinEvent -LogName System -MaxEvents 100 | ? Message -match 'Spooler'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Spooler-Logs prüfen.
- Hängende Spool-Dateien nur bei gestopptem Spooler entfernen.
- Zuletzt installierte problematische Treiber deinstallieren/ersetzen.
- Dienst erneut starten.

## Weiterführende Prüfung

- PrintService-Operational-Log prüfen.
- Nicht pauschal alle Druckertreiber entfernen.
