# Kubernetes: OOMKilled

## Symptom

Pod/Container wird beendet; Status zeigt OOMKilled.

## Bedeutung

Container überschreitet sein Memory-Limit oder Node steht unter starkem Speicherdruck.

## Typische Ursachen

- Limit zu niedrig
- Memory Leak
- Lastspitze
- Node pressure

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl describe pod <pod>
kubectl top pod <pod> --containers
kubectl top nodes
kubectl get pod <pod> -o jsonpath='{.status.containerStatuses[*].lastState.terminated.reason}'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Memory-Verbrauch messen.
- Requests/Limits realistisch setzen.
- Anwendungsleck beheben.
- Node-Kapazität prüfen.

## Weiterführende Prüfung

- VPA/Monitoring nutzen.
- Eviction wegen NodePressure von Container-OOM unterscheiden.
