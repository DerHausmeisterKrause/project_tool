# Kubernetes: Forbidden / RBAC

## Symptom

kubectl oder Workload erhält `forbidden: User ... cannot ...`.

## Bedeutung

RBAC erlaubt dem Benutzer oder ServiceAccount die Aktion nicht.

## Typische Ursachen

- Role/ClusterRole fehlt
- Binding fehlt
- Falscher ServiceAccount
- Namespace falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl auth can-i <verb> <resource> -n <ns>
kubectl get role,rolebinding -n <ns>
kubectl get clusterrole,clusterrolebinding
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Benötigte Berechtigung exakt bestimmen.
- Minimal passende Role/ClusterRole und Binding erstellen oder korrigieren.
- Keine pauschale cluster-admin-Zuweisung als Standardlösung.

## Weiterführende Prüfung

- Impersonation mit `kubectl auth can-i --as` nur mit passenden Rechten testen.
- ServiceAccount des Pods prüfen.
