# Kubernetes Pod bleibt Pending

## Symptom

Pod wird nicht auf einen Node geplant.

## Bedeutung

Scheduler findet keinen passenden Node oder Volumes/Ressourcen fehlen.

## Typische Ursachen

- CPU/RAM nicht verfügbar
- Taints/Tolerations
- NodeSelector/Affinity
- PVC unbound

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl describe pod <pod>
kubectl get nodes
kubectl top nodes
kubectl get pvc
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Scheduler-Events lesen.
- Ressourcenrequests, Taints, Affinity und PVCs prüfen.
- Kapazität schaffen oder Scheduling-Regeln korrigieren.

## Weiterführende Prüfung

- Nicht nur Limits, sondern Requests betrachten.
- Cluster Autoscaler-Status prüfen, falls vorhanden.
