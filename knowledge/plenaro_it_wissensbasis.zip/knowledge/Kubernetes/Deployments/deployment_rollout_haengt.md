# Kubernetes Deployment Rollout hängt

## Symptom

`kubectl rollout status` wird nicht erfolgreich.

## Bedeutung

Neue ReplicaSets liefern nicht genug Ready Pods.

## Typische Ursachen

- Readiness-Probe fehlschlägt
- ImagePull
- CrashLoop
- Ressourcen fehlen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl rollout status deployment/<name>
kubectl describe deployment <name>
kubectl get rs
kubectl get pods -l app=<label>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Nicht bereite Pods identifizieren.
- Pod-Events und Logs prüfen.
- Bei fehlerhaftem Release Rollback nur nach Bewertung: `kubectl rollout undo deployment/<name>`.

## Weiterführende Prüfung

- maxUnavailable/maxSurge prüfen.
- PDB und Scheduler-Ereignisse berücksichtigen.
