# Kubernetes DNS im Cluster fehlerhaft

## Symptom

Pods können Services oder externe Namen nicht auflösen.

## Bedeutung

CoreDNS/kube-dns, Service-Routing oder Pod-resolv.conf ist gestört.

## Typische Ursachen

- CoreDNS Pods down
- ClusterIP nicht erreichbar
- NetworkPolicy blockiert DNS
- Upstream Resolver fehlerhaft

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl get pods -n kube-system -l k8s-app=kube-dns
kubectl get svc -n kube-system kube-dns
kubectl logs -n kube-system -l k8s-app=kube-dns
kubectl exec <pod> -- cat /etc/resolv.conf
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- CoreDNS-Status und Logs prüfen.
- DNS-Service-IP aus Pods erreichen.
- NetworkPolicy für UDP/TCP 53 prüfen.
- Upstream-DNS in CoreDNS-Konfiguration validieren.

## Weiterführende Prüfung

- Kurzname vs. FQDN `<svc>.<ns>.svc.cluster.local` testen.
- NodeLocal DNS Cache berücksichtigen.
