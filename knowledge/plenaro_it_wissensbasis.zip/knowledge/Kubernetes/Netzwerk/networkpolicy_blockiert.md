# Kubernetes NetworkPolicy blockiert Verkehr

## Symptom

Pods sind grundsätzlich gesund, bestimmte Verbindungen funktionieren nach NetworkPolicy-Änderung nicht.

## Bedeutung

Ingress/Egress ist durch Namespace-/Pod-Selector oder Portregeln nicht erlaubt.

## Typische Ursachen

- Default deny
- Selector matcht nicht
- DNS-Egress vergessen
- Falscher Port

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl get networkpolicy -A
kubectl describe networkpolicy <name> -n <ns>
kubectl get pods -n <ns> --show-labels
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Policies für Quell- und Zielnamespace auswerten.
- Benötigten DNS-Egress berücksichtigen.
- Minimal notwendige Ports/Peers erlauben.

## Weiterführende Prüfung

- CNI muss NetworkPolicy unterstützen.
- Policy-Verhalten mit Testpod reproduzieren.
