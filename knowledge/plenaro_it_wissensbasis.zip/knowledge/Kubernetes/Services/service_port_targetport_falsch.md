# Kubernetes Service: port/targetPort falsch

## Symptom

Service existiert und Endpoints sind vorhanden, Anwendung ist trotzdem nicht erreichbar.

## Bedeutung

Service leitet auf einen Port weiter, auf dem der Container nicht lauscht.

## Typische Ursachen

- targetPort falsch
- Named Port mismatch
- App lauscht auf anderem Port

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl get svc <svc> -o yaml
kubectl get pod <pod> -o yaml
kubectl exec <pod> -- ss -tulpn 2>/dev/null || true
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Tatsächlichen Container-Listen-Port prüfen.
- targetPort bzw. named port korrigieren.
- Service danach erneut testen.

## Weiterführende Prüfung

- ContainerPort ist Dokumentation/Metadatum und öffnet selbst keinen Port.
- Probe-Ports ebenfalls prüfen.
