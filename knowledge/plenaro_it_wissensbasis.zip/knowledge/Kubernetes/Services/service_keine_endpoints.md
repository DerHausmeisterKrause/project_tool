# Kubernetes Service hat keine Endpoints

## Symptom

Service-DNS löst auf, Verbindungen erreichen aber keine Pods.

## Bedeutung

Service-Selector matcht keine Ready Pods oder EndpointSlices sind leer.

## Typische Ursachen

- Selector falsch
- Pods nicht Ready
- Labels fehlen
- Port/targetPort falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
kubectl get svc <svc> -o yaml
kubectl get endpoints <svc>
kubectl get endpointslice -l kubernetes.io/service-name=<svc>
kubectl get pods --show-labels
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Selector mit Pod-Labels abgleichen.
- Readiness der Pods prüfen.
- Port/targetPort korrigieren.

## Weiterführende Prüfung

- Headless Service Besonderheiten beachten.
- NetworkPolicy erst nach vorhandenen Endpoints prüfen.
