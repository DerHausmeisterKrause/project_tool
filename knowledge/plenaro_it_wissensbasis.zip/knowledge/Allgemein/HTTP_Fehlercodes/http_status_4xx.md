# HTTP 4xx – Client-/Requestfehler

## Symptom

Webanwendung antwortet mit 400, 401, 403, 404, 409, 413 oder 429.

## Bedeutung

4xx zeigt, dass Anfrage, Berechtigung, Ressource oder Rate-Limit problematisch ist.

## Typische Ursachen

- 400 Bad Request
- 401 Unauthorized (Authentifizierung erforderlich/fehlgeschlagen)
- 403 Forbidden
- 404 Not Found
- 409 Conflict
- 413 Content Too Large
- 429 Too Many Requests

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
curl -v https://<host>/<pfad>
curl -I https://<host>/<pfad>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Code zusammen mit Response-Body und Server-/Anwendungslog auswerten.
- Nicht jeden 4xx als Netzwerkfehler behandeln.

## Weiterführende Prüfung

- Proxy/WAF kann den Status erzeugen.
- 401 und 403 semantisch unterscheiden.
