# HTTP 5xx – Server-/Gatewayfehler

## Symptom

Webanwendung antwortet mit 500, 502, 503 oder 504.

## Bedeutung

5xx weist auf Fehler in Server, Backend oder Gateway-Pfad hin.

## Typische Ursachen

- 500 Internal Server Error
- 502 Bad Gateway
- 503 Service Unavailable
- 504 Gateway Timeout

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
curl -v https://<host>/
Webserver-Errorlog
Backend-Service-Logs
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Feststellen, welche Schicht den Status erzeugt.
- Backend direkt testen.
- Logs zum Request-Zeitpunkt korrelieren.

## Weiterführende Prüfung

- Retry bei 503 kann sinnvoll sein, ersetzt aber keine Ursachenbehebung.
- Request-ID verwenden, falls vorhanden.
