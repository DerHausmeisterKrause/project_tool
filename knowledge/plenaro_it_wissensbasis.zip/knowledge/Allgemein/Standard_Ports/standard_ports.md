# Standardports – Schnellreferenz

## Symptom

Schnelle Zuordnung häufiger Infrastrukturprotokolle.

## Bedeutung

Standardports unterstützen Diagnose und Firewallplanung.

## Typische Ursachen

- 22/TCP SSH
- 25/TCP SMTP
- 53/UDP+TCP DNS
- 67/68 UDP DHCP
- 80/TCP HTTP
- 123/UDP NTP
- 389 LDAP
- 443/TCP HTTPS
- 445/TCP SMB
- 636/TCP LDAPS
- 1433/TCP MS SQL
- 3306/TCP MySQL/MariaDB
- 3389/TCP+UDP RDP
- 5432/TCP PostgreSQL
- 6443/TCP Kubernetes API

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
netstat -ano
Test-NetConnection <host> -Port <port>
nc -vz <host> <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Immer reale Konfiguration prüfen; Anwendungen können auf anderen Ports laufen.
- Firewallregeln nur für benötigte Quellen/Ziele öffnen.

## Weiterführende Prüfung

- RPC und passive FTP-Modi können zusätzliche Ports nutzen.
- ICMP ist kein Port-Protokoll.
