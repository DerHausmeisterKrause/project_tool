# Porttests richtig interpretieren

## Symptom

Ein Administrator möchte prüfen, ob ein Dienst erreichbar ist.

## Bedeutung

Porttest muss Protokoll, Ziel, Richtung und Anwendungsantwort berücksichtigen.

## Typische Ursachen

- TCP kann mit connect getestet werden
- UDP benötigt meist Protokollverständnis
- Proxy/NAT kann Ergebnis verändern

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
Windows: Test-NetConnection <host> -Port <port>
Linux: nc -vz <host> <port>
curl -v https://<host>:<port>/
openssl s_client -connect <host>:<port> -servername <host>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Bei TCP zuerst Connect testen, danach Anwendung/TLS.
- Bei UDP Paketmitschnitt und echte Applikationsanfrage bevorzugen.

## Weiterführende Prüfung

- Ping sagt nichts über TCP-Portstatus aus.
- Lokalen und Remote-Test vergleichen.
