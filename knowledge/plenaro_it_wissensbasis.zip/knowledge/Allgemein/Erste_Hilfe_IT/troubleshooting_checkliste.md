# Universelle Troubleshooting-Checkliste

## Symptom

Ein Fehler ist unspezifisch und betrifft möglicherweise mehrere Schichten.

## Bedeutung

Eine feste Reihenfolge verhindert Aktionismus.

## Typische Ursachen

- Scope
- Zeitpunkt
- Änderungen
- Abhängigkeiten
- Reproduzierbarkeit

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
date
uptime
ip a
ip r
ss -tulpn
systemctl --failed
journalctl -b -p err..alert
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Problem klar beschreiben.
- Scope eingrenzen.
- Hypothese mit messbarem Test prüfen.
- Nur eine wesentliche Änderung pro Schritt.
- Ergebnis dokumentieren und ggf. zurückrollen.

## Weiterführende Prüfung

- Symptom und Ursache getrennt halten.
- Monitoring nach Wiederherstellung prüfen.
