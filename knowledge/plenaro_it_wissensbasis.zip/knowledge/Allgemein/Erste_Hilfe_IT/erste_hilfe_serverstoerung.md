# Erste Hilfe bei Serverstörung

## Symptom

Ein Server oder Dienst ist akut gestört und Ursache noch unbekannt.

## Bedeutung

Strukturiertes Vorgehen reduziert Folgeschäden und sichert verwertbare Diagnoseinformationen.

## Typische Ursachen

- Dienstfehler
- Ressourcenengpass
- Netzwerk/Storage
- Letzte Änderung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
uptime
free -h
df -h
df -i
systemctl --failed
ss -tulpn
journalctl -b -p err..alert
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Fehlerzeit und Impact festhalten.
- Nicht sofort rebooten, wenn Logs/State noch analysierbar sind.
- Letzte Änderungen identifizieren.
- Kleinste reversible Maßnahme wählen.
- Nach Fix Funktion und Monitoring verifizieren.

## Weiterführende Prüfung

- Bei Security-Verdacht Incident-Prozess statt Standardtroubleshooting nutzen.
- Kommunikation und Timeline dokumentieren.
