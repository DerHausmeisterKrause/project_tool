# Windows Diagnosebefehle – Referenz

## Symptom

Schnelle Sammlung häufig benötigter Windows-Diagnosebefehle.

## Bedeutung

Die Befehle decken Netzwerk, Prozesse, Dienste, Ereignisse und Systemdateien ab.

## Typische Ursachen

- Netzwerk
- Dienste
- Logs
- Systemdateien

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ipconfig /all
route print
arp -a
nslookup <name>
Test-NetConnection <host> -Port <port>
Get-Service
Get-Process
Get-WinEvent -LogName System -MaxEvents 50
sfc /scannow
DISM /Online /Cleanup-Image /ScanHealth
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Befehle passend zum Fehlerbild auswählen.
- Ausgaben mit Zeitstempel dokumentieren.

## Weiterführende Prüfung

- Administrative Rechte sind für manche Befehle erforderlich.
- PowerShell und CMD-Syntax nicht vermischen.
