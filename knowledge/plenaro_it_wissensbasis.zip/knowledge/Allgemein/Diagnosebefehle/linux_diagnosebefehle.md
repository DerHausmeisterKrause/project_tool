# Linux Diagnosebefehle – Referenz

## Symptom

Schnelle Sammlung häufig benötigter Linux-Diagnosebefehle.

## Bedeutung

Die Befehle decken systemd, Netzwerk, Ressourcen, Dateien und Logs ab.

## Typische Ursachen

- systemd
- Netzwerk
- Dateisystem
- Prozesse
- Logs

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl status <dienst>
journalctl -u <dienst> -b
ss -tulpn
lsof -i :<port>
ps aux
df -h
df -i
free -h
top
ip a
ip r
ping <host>
curl -v <url>
dig <name>
chmod <mode> <pfad>
chown <user>:<group> <pfad>
dmesg -T
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit dem kleinsten passenden Befehl beginnen.
- Logs und Ressourcen zum Fehlerzeitpunkt korrelieren.

## Weiterführende Prüfung

- Produktive Änderungen erst nach Diagnose durchführen.
- Passwörter/Tokens nicht in Tickets kopieren.
