# Docker Compose: Dienstabhängigkeit noch nicht bereit

## Symptom

Anwendungscontainer startet vor Datenbank/API und schlägt zunächst fehl.

## Bedeutung

`depends_on` steuert Startreihenfolge, garantiert aber ohne passende Healthchecks nicht die fachliche Bereitschaft eines Dienstes.

## Typische Ursachen

- DB braucht länger
- Kein Healthcheck
- App hat keine Retry-Logik

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker compose ps
docker compose logs <service>
docker inspect <container> --format '{{json .State.Health}}'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Healthchecks definieren, wenn sinnvoll.
- Anwendung mit Retry/Backoff ausstatten.
- Abhängigkeiten nicht nur mit festen Sleeps kaschieren.

## Weiterführende Prüfung

- Compose-Dateiversion und unterstützte `depends_on`-Semantik prüfen.
- Healthcheck muss die echte Betriebsbereitschaft testen.
