# Docker Compose: Variable nicht gesetzt

## Symptom

Compose warnt vor nicht gesetzter Variable oder erzeugt falsche Konfiguration.

## Bedeutung

Environment-Substitution aus `.env`, Shell oder `--env-file` liefert keinen Wert.

## Typische Ursachen

- .env fehlt
- Falscher Arbeitsordner
- Variable anders benannt
- Shell überschreibt Wert

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker compose config
docker compose config --environment
pwd
env | sort
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Gerenderte Konfiguration mit `docker compose config` prüfen.
- `.env` am erwarteten Ort bereitstellen oder `--env-file` verwenden.
- Secrets nicht unverschlüsselt in Git ablegen.

## Weiterführende Prüfung

- Unterschied zwischen Compose-Substitution und `environment:` im Container beachten.
- Defaultwerte `${VAR:-default}` bewusst nutzen.
