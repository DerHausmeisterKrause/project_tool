# Docker-Container startet nicht

## Symptom

Container wechselt sofort auf Exited oder Restarting.

## Bedeutung

EntryPoint/Command, Konfiguration, Mounts oder Abhängigkeiten schlagen beim Start fehl.

## Typische Ursachen

- Falscher Command
- Umgebungsvariable fehlt
- Volume-Datei fehlt
- Anwendung crasht

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker ps -a
docker logs <container>
docker inspect <container>
docker start -a <container>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exit Code und Logs prüfen.
- Command/Entrypoint und Environment validieren.
- Mount-Pfade und Rechte kontrollieren.
- Fehler in der Anwendung beheben statt nur Restart-Policy zu erhöhen.

## Weiterführende Prüfung

- OOMKilled in `docker inspect` prüfen.
- Healthcheck getrennt vom Prozessstatus betrachten.
