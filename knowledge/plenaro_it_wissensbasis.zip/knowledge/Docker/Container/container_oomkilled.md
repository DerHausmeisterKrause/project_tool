# Docker-Container OOMKilled

## Symptom

Container beendet sich mit OOMKilled oder Exit 137.

## Bedeutung

Der Prozess wurde wegen Speichermangel bzw. cgroup-Memory-Limit beendet.

## Typische Ursachen

- memory limit zu klein
- Memory Leak
- Host unter Speicherdruck

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker inspect <container> --format '{{.State.OOMKilled}}'
docker stats
free -h
journalctl -k | grep -i oom
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Speicherverbrauch und Limits prüfen.
- Anwendung optimieren oder Limit realistisch erhöhen.
- Host-Speicherdruck beheben.

## Weiterführende Prüfung

- Swap-/MemorySwap-Konfiguration prüfen.
- Monitoring für Container-RSS einrichten.
