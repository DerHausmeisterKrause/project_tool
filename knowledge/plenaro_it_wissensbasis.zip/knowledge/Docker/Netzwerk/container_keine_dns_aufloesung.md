# Docker-Container kann DNS nicht auflösen

## Symptom

Im Container schlagen DNS-Abfragen fehl, Host selbst kann auflösen.

## Bedeutung

Docker-internes DNS oder Upstream-Resolver ist falsch/unerreichbar.

## Typische Ursachen

- daemon DNS falsch
- VPN/Firewall
- resolv.conf vom Host ungeeignet
- Custom network Problem

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker exec <container> cat /etc/resolv.conf
docker exec <container> getent hosts example.org
docker network inspect <network>
docker info
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Container-Resolver prüfen.
- Docker-Daemon-DNS bei Bedarf explizit konfigurieren.
- Firewall/VPN-Routing zum Upstream-DNS prüfen.
- Docker nach Daemon-Konfigurationsänderung kontrolliert neu starten.

## Weiterführende Prüfung

- 127.0.0.11 ist bei Docker-Netzwerken normal.
- Hostnames zwischen Containern nur im gemeinsamen benutzerdefinierten Netzwerk erwarten.
