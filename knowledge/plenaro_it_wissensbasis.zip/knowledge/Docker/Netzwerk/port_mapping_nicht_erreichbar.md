# Docker-Port-Mapping nicht erreichbar

## Symptom

`docker ps` zeigt Port-Mapping, Dienst ist extern trotzdem nicht erreichbar.

## Bedeutung

Anwendung lauscht im Container nur auf localhost, Host-Firewall blockiert oder Mapping ist falsch.

## Typische Ursachen

- Bind auf 127.0.0.1 im Container
- Falscher Hostport
- Firewall
- Containerdienst down

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker ps
docker port <container>
docker exec <container> ss -tulpn
curl -v http://127.0.0.1:<hostport>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Im Container prüfen, ob Dienst auf 0.0.0.0 bzw. Container-IP lauscht.
- Port-Mapping validieren.
- Host-Firewall und Reverse Proxy prüfen.

## Weiterführende Prüfung

- IPv6-Mappings prüfen.
- Docker-iptables/nftables-Regeln nicht manuell ohne Konzept verändern.
