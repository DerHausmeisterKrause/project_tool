# Docker overlay2: No space left on device

## Symptom

Builds oder Container scheitern mit Speicherplatzfehlern unter Docker-Datenverzeichnis.

## Bedeutung

Images, Layer, Buildcache oder Logs füllen das Dateisystem/Inodes.

## Typische Ursachen

- Viele alte Images
- Buildcache
- Containerlogs
- Inodes voll

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker system df
df -h /var/lib/docker
df -i /var/lib/docker
du -sh /var/lib/docker/* 2>/dev/null | sort -h
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Verbrauch mit `docker system df` bewerten.
- Unbenutzte Artefakte gezielt entfernen, z. B. `docker image prune` oder `docker builder prune`.
- Produktive Volumes nicht mit pauschalem prune löschen.

## Weiterführende Prüfung

- JSON-File-Logrotation konfigurieren.
- Datenroot auf ausreichend dimensioniertem Storage betreiben.
