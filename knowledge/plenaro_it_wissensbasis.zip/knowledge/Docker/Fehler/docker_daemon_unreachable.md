# Cannot connect to the Docker daemon

## Symptom

Docker CLI meldet, dass keine Verbindung zum Docker daemon möglich ist.

## Bedeutung

Docker Engine läuft nicht oder der Client verwendet falschen Socket/Context.

## Typische Ursachen

- docker.service gestoppt
- Falscher DOCKER_HOST
- Berechtigung auf Socket fehlt
- Falscher Docker Context

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl status docker
docker context ls
echo $DOCKER_HOST
ls -l /var/run/docker.sock
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Docker-Dienst starten/reparieren.
- Context und DOCKER_HOST korrigieren.
- Socket-Berechtigungen bzw. Gruppenmitgliedschaft korrekt konfigurieren.

## Weiterführende Prüfung

- Mitgliedschaft in docker-Gruppe gewährt weitreichende Rechte.
- Rootless Docker separat prüfen.
