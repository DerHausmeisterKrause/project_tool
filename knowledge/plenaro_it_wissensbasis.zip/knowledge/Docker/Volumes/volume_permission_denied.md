# Docker-Volume: Permission denied

## Symptom

Container kann in gemountetes Verzeichnis nicht schreiben.

## Bedeutung

UID/GID im Container passen nicht zu Rechten des Hostpfads oder MAC-Policy blockiert.

## Typische Ursachen

- Bind Mount falscher Owner
- Container läuft non-root
- SELinux/AppArmor
- Read-only Mount

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker inspect <container>
ls -ln <hostpfad>
docker exec <container> id
docker exec <container> ls -ln <containerpfad>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- UID/GID zwischen Containerprozess und Hostpfad abgleichen.
- Ownership/Rechte minimal anpassen.
- Read-only Flag und Security-Policy prüfen.

## Weiterführende Prüfung

- Bei SELinux passende Label-Optionen verwenden, wenn Distribution das erfordert.
- Nicht pauschal chmod 777.
