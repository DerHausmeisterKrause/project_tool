# Docker-Volume-Daten scheinen verschwunden

## Symptom

Nach Container-Neuerstellung sind erwartete Daten nicht sichtbar.

## Bedeutung

Es wurde ein anderes Volume/Bind-Mount verwendet oder Daten lagen im beschreibbaren Container-Layer.

## Typische Ursachen

- Anonymer Volumewechsel
- Falscher Compose-Projektname
- Bind-Pfad geändert
- Daten nie persistent gemountet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
docker volume ls
docker volume inspect <volume>
docker inspect <container>
docker compose config
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Nicht sofort alte Volumes löschen.
- Mounts des alten und neuen Containers vergleichen.
- Richtiges Volume wieder einbinden.
- Persistente Pfade der Anwendung dokumentieren.

## Weiterführende Prüfung

- Compose-Projektname berücksichtigen.
- Backups von Volumes regelmäßig testen.
