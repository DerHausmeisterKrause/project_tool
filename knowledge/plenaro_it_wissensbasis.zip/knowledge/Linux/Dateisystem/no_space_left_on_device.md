# No space left on device

## Symptom

Programme melden `No space left on device`, Schreibvorgänge schlagen fehl.

## Bedeutung

Entweder sind Datenblöcke oder Inodes des Dateisystems erschöpft.

## Typische Ursachen

- Dateisystem voll
- Inodes voll
- Gelöschte aber noch geöffnete große Datei
- Quota erreicht

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
df -h
df -i
du -xhd1 / | sort -h
lsof +L1
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit `df -h` und `df -i` unterscheiden, ob Platz oder Inodes fehlen.
- Große Verzeichnisse identifizieren.
- Logs kontrolliert rotieren/löschen.
- Bei offenen gelöschten Dateien verursachenden Prozess neu starten, wenn betrieblich möglich.

## Weiterführende Prüfung

- Quotas prüfen.
- Nicht blind Dateien unter /var/lib oder Datenbankverzeichnissen löschen.
