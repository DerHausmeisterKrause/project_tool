# Read-only file system

## Symptom

Schreibzugriffe scheitern mit `Read-only file system`.

## Bedeutung

Das Dateisystem ist read-only gemountet oder wurde wegen Fehlern automatisch schreibgeschützt.

## Typische Ursachen

- Dateisystemfehler
- Storage-I/O-Fehler
- Mount-Option ro
- Kernel remount-ro

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
findmnt -no TARGET,SOURCE,FSTYPE,OPTIONS /
mount | grep ' ro[,$ ]'
dmesg -T | tail -n 100
journalctl -k -b
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Kernel-/Storage-Fehler zuerst prüfen.
- Bei Dateisystemfehlern Wartungsfenster und Offline-Dateisystemprüfung einplanen.
- Nicht einfach rw remounten, wenn I/O-Fehler oder Dateisystemkorruption vorliegen.

## Weiterführende Prüfung

- SMART/Storage-Backend prüfen.
- Nach Reparatur Mount-Optionen in /etc/fstab validieren.
