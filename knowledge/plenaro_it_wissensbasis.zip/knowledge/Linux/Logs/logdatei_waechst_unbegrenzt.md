# Logdatei wächst unbegrenzt

## Symptom

Eine Datei unter /var/log oder einem Anwendungsverzeichnis verbraucht immer mehr Speicher.

## Bedeutung

Logging ist zu ausführlich oder Rotation funktioniert nicht.

## Typische Ursachen

- logrotate-Regel fehlt/fehlerhaft
- Debug-Logging aktiv
- Anwendung ignoriert Rotation
- Copytruncate/Signal falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
du -sh /var/log/* 2>/dev/null | sort -h
logrotate -d /etc/logrotate.conf
lsof +L1
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Verursachende Logdatei und Schreibprozess ermitteln.
- Logging-Level korrigieren.
- logrotate-Regel testen.
- Anwendungen, die Dateien offen halten, mit vorgesehenem Reload/Signal zur Neueröffnung bewegen.

## Weiterführende Prüfung

- Nicht aktive Datenbank-/Journaldateien als normale Logs behandeln.
- Kompression und Aufbewahrung definieren.
