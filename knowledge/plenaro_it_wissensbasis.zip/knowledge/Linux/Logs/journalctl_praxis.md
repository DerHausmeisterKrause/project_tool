# journalctl – praxisnahe Fehlersuche

## Symptom

Ein Dienst oder Bootproblem muss zeitlich und nach Unit eingegrenzt werden.

## Bedeutung

journalctl liest das systemd-Journal und kann nach Unit, Boot, Priorität und Zeit filtern.

## Typische Ursachen

- Fehler ist nur im Journal sichtbar
- Zu viele unstrukturierte Logmeldungen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
journalctl -u <dienst> -b --no-pager
journalctl -xe
journalctl -b -p err..alert
journalctl --since '30 min ago'
journalctl -k -b
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit Unit und aktuellem Boot beginnen.
- Zeitraum auf den Fehlerzeitpunkt begrenzen.
- Kernelmeldungen getrennt prüfen, wenn Storage/Netzwerk/Treiber beteiligt sind.

## Weiterführende Prüfung

- Persistenz unter /var/log/journal prüfen, wenn Logs Reboots überleben sollen.
- Nicht nur `-xe` verwenden; Unit-spezifische Logs sind oft präziser.
