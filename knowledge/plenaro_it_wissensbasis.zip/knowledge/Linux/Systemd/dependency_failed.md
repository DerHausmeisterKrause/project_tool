# systemd: Dependency failed

## Symptom

Beim Start einer Unit erscheint `Dependency failed for ...`.

## Bedeutung

Eine erforderliche Unit, ein Mount, Socket oder Target ist nicht erfolgreich verfügbar.

## Typische Ursachen

- Mount fehlgeschlagen
- Requires=/After=-Abhängigkeit fehlerhaft
- Netzwerkziel nicht erreicht
- Vorbedingung fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl status <dienst>
systemctl list-dependencies <dienst>
journalctl -b -p warning
systemctl --failed
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Fehlerhafte Abhängigkeit identifizieren und zuerst reparieren.
- Bei Mounts fstab und Datenträger prüfen.
- Unit-Beziehungen nicht blind entfernen.

## Weiterführende Prüfung

- Mit `systemctl cat <dienst>` Requires/Wants/After kontrollieren.
- Bootreihenfolge nur anpassen, wenn die Semantik verstanden ist.
