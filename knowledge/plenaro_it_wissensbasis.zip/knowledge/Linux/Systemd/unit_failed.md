# systemd: Unit failed

## Symptom

`systemctl` zeigt einen Dienst als `failed`.

## Bedeutung

Der Prozess ist beendet, konnte nicht gestartet werden oder eine Startbedingung ist fehlgeschlagen.

## Typische Ursachen

- Fehlerhafte Konfiguration
- Fehlende Datei/Rechte
- Port belegt
- Abhängigkeit fehlgeschlagen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl status <dienst> --no-pager -l
journalctl -u <dienst> -b --no-pager
systemctl show <dienst> -p ExecStart -p User -p Group
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exakte Fehlermeldung im Journal lesen.
- Konfiguration mit dem Programm-eigenen Testbefehl prüfen, falls vorhanden.
- Dateien, Rechte, Ports und Abhängigkeiten reparieren.
- Danach `systemctl restart <dienst>`.

## Weiterführende Prüfung

- `systemctl cat <dienst>` auf Overrides prüfen.
- Nach Änderungen an Unit-Dateien `systemctl daemon-reload` ausführen.
