# SSH: Permission denied

## Symptom

SSH meldet `Permission denied (publickey)` oder `Permission denied` bei der Anmeldung.

## Bedeutung

Authentifizierung wurde vom Server abgelehnt.

## Typische Ursachen

- Falscher Benutzer
- Public Key fehlt/falsch
- authorized_keys-Rechte falsch
- PasswordAuthentication deaktiviert
- AllowUsers/AllowGroups

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ssh -vvv user@host
sshd -T | grep -Ei 'passwordauthentication|pubkeyauthentication|allowusers|allowgroups'
ls -ld ~/.ssh ~/.ssh/authorized_keys
journalctl -u ssh -b
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Richtigen Benutzer verwenden.
- Public Key und authorized_keys prüfen.
- Für OpenSSH übliche restriktive Rechte setzen, z. B. `chmod 700 ~/.ssh` und `chmod 600 ~/.ssh/authorized_keys`.
- Serverseitige AllowUsers/AllowGroups-Regeln prüfen.

## Weiterführende Prüfung

- Home-Verzeichnis und Ownership kontrollieren.
- Bei SELinux-Systemen zusätzlich Security Context prüfen.
