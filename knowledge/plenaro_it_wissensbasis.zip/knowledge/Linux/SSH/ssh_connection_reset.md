# SSH: Connection reset

## Symptom

SSH-Verbindung wird beim Aufbau oder während der Sitzung mit `Connection reset by peer` beendet.

## Bedeutung

Die TCP-Verbindung wurde aktiv von Gegenstelle oder Zwischenkomponente zurückgesetzt.

## Typische Ursachen

- sshd beendet Verbindung
- Fail2ban/Firewall
- Load Balancer/NAT Timeout
- MaxStartups/Rate-Limit

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ssh -vvv user@host
journalctl -u ssh --since '-10 min'
ss -tnp | grep ':22'
fail2ban-client status 2>/dev/null
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Serverlog zum exakten Zeitpunkt prüfen.
- Fail2ban/Firewall-Regeln kontrollieren.
- Bei Verbindungsabbrüchen nach Inaktivität Keepalive- und NAT-Timeouts prüfen.

## Weiterführende Prüfung

- `sshd -T` auf MaxStartups/ClientAlive-Parameter prüfen.
- Paketmitschnitt bei unklaren Resets verwenden.
