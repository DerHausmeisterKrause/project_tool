# Connection timed out

## Symptom

TCP-Verbindung oder SSH/HTTP-Aufruf läuft in einen Timeout.

## Bedeutung

Pakete erreichen Ziel oder Rückweg nicht oder werden still verworfen.

## Typische Ursachen

- Firewall DROP
- Routingfehler
- Host offline
- Security Group/ACL
- MTU-/VPN-Probleme

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip a
ip r
ping <host>
traceroute <host>
nc -vz -w 5 <host> <port>
tcpdump -ni any host <host>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Routing und Gateway prüfen.
- Mit tcpdump feststellen, ob SYN gesendet und Antwort empfangen wird.
- Firewalls/ACLs auf beiden Seiten und Zwischenkomponenten prüfen.

## Weiterführende Prüfung

- Hin- und Rückweg beachten.
- Bei nur großen Paketen MTU/PMTUD untersuchen.
