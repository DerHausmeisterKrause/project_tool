# Connection refused

## Symptom

Client meldet `Connection refused` beim Verbindungsaufbau.

## Bedeutung

Der Zielhost ist erreichbar, aber auf dem Zielport nimmt kein Dienst die Verbindung an oder eine Firewall weist aktiv zurück.

## Typische Ursachen

- Dienst gestoppt
- Dienst lauscht auf anderer IP/Port
- Container-Port nicht veröffentlicht
- Firewall REJECT

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
systemctl status <dienst>
curl -v http://<host>:<port>/
nc -vz <host> <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Am Ziel prüfen, ob der Dienst auf dem erwarteten Port und Interface lauscht.
- Dienst starten bzw. Listen-Adresse korrigieren.
- Firewall- und Container-Port-Mappings kontrollieren.

## Weiterführende Prüfung

- Lokalen Test auf `127.0.0.1` mit Remote-Test vergleichen.
- IPv4/IPv6 getrennt prüfen.
