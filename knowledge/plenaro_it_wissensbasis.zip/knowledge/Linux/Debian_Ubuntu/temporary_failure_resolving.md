# Temporary failure resolving

## Symptom

APT, curl oder andere Programme melden `Temporary failure resolving` für einen Hostnamen.

## Bedeutung

Die DNS-Namensauflösung funktioniert temporär oder dauerhaft nicht.

## Typische Ursachen

- Resolver nicht erreichbar
- Falsche /etc/resolv.conf
- systemd-resolved gestört
- Firewall blockiert DNS

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
cat /etc/resolv.conf
resolvectl status
dig deb.debian.org
getent hosts deb.debian.org
ip r
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- IP-Konnektivität zum Gateway und DNS-Server prüfen.
- Resolver-Konfiguration korrigieren.
- Bei systemd-resolved Status und Upstream-DNS prüfen.
- Firewall auf UDP/TCP 53 kontrollieren.

## Weiterführende Prüfung

- `ping 1.1.1.1` gegen `ping deb.debian.org` vergleichen.
- Bei Containern separate DNS-Konfiguration prüfen.
