# Debian/Ubuntu bootet nach Upgrade nicht

## Symptom

Nach Paket-/Release-Upgrade startet das System nicht korrekt oder fällt in Rescue/Emergency Mode.

## Bedeutung

Kernel, initramfs, fstab oder Paketkonfiguration ist nach dem Upgrade inkonsistent.

## Typische Ursachen

- Fehlerhafte fstab
- Initramfs unvollständig
- Kernelproblem
- Nicht fertig konfiguriertes Paket

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
journalctl -xb
systemctl --failed
cat /etc/fstab
dpkg --audit
ls -l /boot
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Fehler im Bootlog zuerst eingrenzen.
- Fehlerhafte fstab-Einträge korrigieren.
- Bei Paketproblemen `dpkg --configure -a` und passende `apt -f install`-Reparatur im Rescue-System durchführen.
- Initramfs nur bei konkretem Bedarf neu erzeugen.

## Weiterführende Prüfung

- Freien Platz in /boot und / prüfen.
- Vor Kernelentfernung sicherstellen, dass ein bootfähiger Kernel verbleibt.
