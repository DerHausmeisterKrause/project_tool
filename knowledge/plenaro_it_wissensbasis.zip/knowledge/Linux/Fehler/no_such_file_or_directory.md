# No such file or directory

## Symptom

Befehl oder Dienst meldet `No such file or directory`, obwohl die Datei scheinbar existiert.

## Bedeutung

Pfad fehlt, Symlink ist kaputt, Interpreter/Loader fehlt oder WorkingDirectory ist falsch.

## Typische Ursachen

- Tippfehler
- Broken symlink
- Shebang verweist auf fehlenden Interpreter
- Dynamischer Loader fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ls -la <pfad>
readlink -f <pfad>
file <datei>
head -n 1 <script>
ldd <binary>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Vollständigen Pfad und Symlinkziel prüfen.
- Bei Skripten Shebang kontrollieren.
- Bei Binärdateien Architektur und dynamischen Loader mit `file`/`ldd` prüfen.

## Weiterführende Prüfung

- systemd `WorkingDirectory=` und `ExecStart=` prüfen.
- CRLF in Shebang-Zeile bei übertragenen Skripten berücksichtigen.
