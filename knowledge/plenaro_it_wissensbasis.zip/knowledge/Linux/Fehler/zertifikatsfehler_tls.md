# TLS-Zertifikatsfehler unter Linux

## Symptom

curl, apt oder Anwendung meldet Zertifikatsprüfung fehlgeschlagen, unknown CA oder hostname mismatch.

## Bedeutung

Die Vertrauenskette, Systemzeit oder der aufgerufene Hostname passt nicht zum Zertifikat.

## Typische Ursachen

- CA fehlt
- Interne CA nicht installiert
- Systemzeit falsch
- Hostname nicht im SAN
- Proxy mit TLS Inspection

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
date -Is
timedatectl
openssl s_client -connect <host>:443 -servername <host> -showcerts
curl -v https://<host>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Systemzeit korrigieren.
- Zertifikatskette und SAN prüfen.
- Benötigte vertrauenswürdige interne CA korrekt im System-Truststore installieren.
- `-k`/`--insecure` nicht als dauerhafte Lösung verwenden.

## Weiterführende Prüfung

- Proxy/TLS-Inspection prüfen.
- Ablaufdatum und Intermediate CAs kontrollieren.
