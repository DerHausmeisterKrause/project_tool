# Address already in use

## Symptom

Dienst startet nicht und meldet `Address already in use` oder `EADDRINUSE`.

## Bedeutung

Ein anderer Prozess lauscht bereits auf der konfigurierten Adresse bzw. dem Port.

## Typische Ursachen

- Zweiter Dienst nutzt denselben Port
- Alter Prozess läuft noch
- Doppelte Instanz
- IPv4/IPv6-Bindings kollidieren

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn | grep ':<port>'
lsof -i :<port>
fuser -v <port>/tcp
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Belegenden Prozess identifizieren.
- Nicht benötigten Prozess sauber stoppen.
- Falls beide Dienste benötigt werden, Listen-Port oder IP eines Dienstes ändern.
- Anschließend Zielservice neu starten.

## Weiterführende Prüfung

- Socket-Activation durch systemd prüfen.
- Container-Port-Mappings berücksichtigen.
