# Permission denied

## Symptom

Shell oder Anwendung meldet `Permission denied` beim Lesen, Schreiben oder Ausführen.

## Bedeutung

Unix-Rechte, Ownership, ACLs, Mount-Optionen oder MAC-Systeme verhindern die Aktion.

## Typische Ursachen

- Falscher Owner/Group
- Mode-Bits
- ACL
- noexec
- SELinux/AppArmor

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
id
ls -la <pfad>
namei -l <pfad>
getfacl <pfad>
findmnt -T <pfad>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Erforderliche Berechtigung entlang des gesamten Pfads prüfen.
- Owner/Group mit `chown` und Mode-Bits mit `chmod` gezielt korrigieren.
- ACLs oder noexec berücksichtigen.
- Keine pauschalen 777-Rechte setzen.

## Weiterführende Prüfung

- AppArmor/SELinux-Logs prüfen, falls klassische Rechte korrekt sind.
- Dienstbenutzer mit `sudo -u <user> <befehl>` testen.
