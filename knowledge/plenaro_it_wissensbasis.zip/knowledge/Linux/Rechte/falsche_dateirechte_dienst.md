# Dienst scheitert wegen falscher Dateirechte

## Symptom

Ein Dienst kann Konfiguration, Zertifikat, Socket oder Datenverzeichnis nicht lesen/schreiben.

## Bedeutung

Der in der Unit konfigurierte Dienstbenutzer besitzt nicht die nötigen Rechte.

## Typische Ursachen

- Datei nach Copy/Restore mit falschem Owner
- Zu restriktive chmod-Werte
- Dienst läuft unter anderem Benutzer als erwartet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl show <dienst> -p User -p Group
ls -la <pfad>
namei -l <pfad>
sudo -u <dienstuser> test -r <datei> && echo lesbar
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Dienstbenutzer identifizieren.
- Ownership und minimal notwendige Rechte herstellen.
- Bei Secrets private Rechte beibehalten und stattdessen Gruppe/Owner passend setzen.

## Weiterführende Prüfung

- Umask und Deployment-Prozess prüfen.
- Bei systemd-Sandboxing ReadWritePaths/ProtectSystem berücksichtigen.
