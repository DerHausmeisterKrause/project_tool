# Too many open files

## Symptom

Anwendung meldet `Too many open files` oder kann keine neuen Sockets/Dateien öffnen.

## Bedeutung

Prozess oder System erreicht ein File-Descriptor-Limit.

## Typische Ursachen

- FD-Leak
- LimitNoFILE zu niedrig
- ulimit niedrig
- Sehr viele Verbindungen/Dateien

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ulimit -n
cat /proc/<PID>/limits
ls /proc/<PID>/fd | wc -l
lsof -p <PID> | wc -l
systemctl show <dienst> -p LimitNOFILE
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Prüfen, ob ein Leak vorliegt.
- Bei legitimer Last Limit passend erhöhen, z. B. systemd `LimitNOFILE=` und danach daemon-reload/restart.
- Anwendung nicht nur durch beliebig hohe Limits kaschieren.

## Weiterführende Prüfung

- Systemweite fs.file-max und aktuelle Nutzung prüfen.
- Metriken für offene FDs überwachen.
