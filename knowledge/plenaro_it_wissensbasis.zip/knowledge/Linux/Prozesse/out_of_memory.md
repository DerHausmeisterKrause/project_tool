# Out of memory / OOM Killer

## Symptom

Prozesse werden unerwartet beendet; Kernel meldet Out of memory oder OOM kill.

## Bedeutung

Der Kernel konnte Speicheranforderungen nicht erfüllen und beendet Prozesse nach OOM-Auswahl.

## Typische Ursachen

- RAM erschöpft
- Memory Leak
- Container-/cgroup-Limit
- Swap fehlt/erschöpft

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
free -h
top
ps aux --sort=-%mem | head
journalctl -k | grep -i -E 'oom|out of memory|killed process'
systemd-cgtop
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Speicherverbraucher identifizieren.
- Anwendungsleck oder Lastursache beheben.
- Sinnvolle Memory-Limits und ggf. Swap dimensionieren.
- Nicht nur den OOM-Killer deaktivieren.

## Weiterführende Prüfung

- Container-/systemd-Limits prüfen.
- Trendmonitoring für RSS, Swap und Commit einrichten.
