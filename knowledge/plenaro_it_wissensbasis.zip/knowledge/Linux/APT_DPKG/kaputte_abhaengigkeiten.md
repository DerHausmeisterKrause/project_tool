# APT: Kaputte Abhängigkeiten

## Symptom

APT meldet unmet dependencies oder nicht erfüllbare Paketabhängigkeiten.

## Bedeutung

Paketstände, Repositories oder teilweise Installationen sind inkonsistent.

## Typische Ursachen

- Gemischte Distribution-Repositories
- Unterbrochenes Upgrade
- Zurückgehaltene Pakete
- Drittanbieter-Paket inkompatibel

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
apt update
apt -f install
apt policy <paket>
apt-mark showhold
grep -Rhs '^deb ' /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Repository-Mix korrigieren.
- Fehlkonfigurierte Pakete fertig konfigurieren.
- `apt -f install` verwenden, nachdem die Paketquellen plausibel sind.
- Problematische Drittanbieterpakete gezielt entfernen/aktualisieren.

## Weiterführende Prüfung

- Kein blindes `dist-upgrade` bei unbekanntem Repository-Mix.
- APT Pinning prüfen.
