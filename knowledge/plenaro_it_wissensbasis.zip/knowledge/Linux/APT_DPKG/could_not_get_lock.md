# APT: Could not get lock

## Symptom

APT/DPKG meldet, dass eine Lock-Datei nicht erworben werden kann.

## Bedeutung

Ein anderer Paketmanagerprozess hält die Sperre oder ein automatischer Updateprozess läuft.

## Typische Ursachen

- apt läuft parallel
- unattended-upgrades
- Software-Updater
- Hängender Paketprozess

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ps aux | grep -E '[a]pt|[d]pkg'
systemctl status apt-daily.service apt-daily-upgrade.service
lsof /var/lib/dpkg/lock-frontend 2>/dev/null
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Laufenden legitimen Prozess beenden lassen.
- Bei hängendem Prozess Ursache prüfen und kontrolliert stoppen.
- Lock-Datei nicht als erste Maßnahme manuell löschen.

## Weiterführende Prüfung

- Nach hartem Abbruch `dpkg --configure -a` prüfen.
- Timer für apt-daily bei Wartungsfenstern berücksichtigen.
