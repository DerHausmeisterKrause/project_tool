# dpkg was interrupted

## Symptom

APT meldet `dpkg was interrupted, you must manually run 'dpkg --configure -a'`.

## Bedeutung

Ein vorheriger Paketvorgang wurde unterbrochen und Pakete sind nicht vollständig konfiguriert.

## Typische Ursachen

- SSH-Abbruch
- Reboot während Upgrade
- Prozess beendet
- Fehler in Paketkonfiguration

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
dpkg --audit
ps aux | grep -E '[a]pt|[d]pkg'
sudo dpkg --configure -a
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Sicherstellen, dass kein legitimer apt/dpkg-Prozess mehr läuft.
- `sudo dpkg --configure -a` ausführen und die konkrete Fehlermeldung beheben.
- Danach `sudo apt -f install` falls Abhängigkeiten defekt sind.

## Weiterführende Prüfung

- Nicht Lock-Dateien löschen, solange Paketprozesse aktiv sind.
- Logs unter /var/log/apt und /var/log/dpkg.log prüfen.
