# Plenaro – lokale IT-Wissensbasis

Diese Wissensbasis ist für lokale KI-Suche, RAG, Helpdesk und Systemadministration strukturiert.

## Strukturprinzip

- Kleine thematisch klare Dateien
- Eindeutige Dateinamen
- Klare Trennung von Symptom, Bedeutung, Ursachen, Diagnose, Befehlen und Lösung
- Keine produktabhängigen Fantasiebefehle
- Platzhalter in spitzen Klammern müssen vor Ausführung ersetzt werden
- Sicherheitskritische Änderungen nie blind ausführen

## Zielgruppen

- Systemadministration
- Helpdesk
- DevOps
- Infrastruktur-/Netzwerkbetrieb
