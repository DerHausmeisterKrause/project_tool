# SQLite: database disk image is malformed

## Symptom

SQLite meldet Korruption der Datenbankdatei.

## Bedeutung

Datenbankseiten sind beschädigt; Ursache kann Storage-, Absturz- oder Kopierfehler sein.

## Typische Ursachen

- Storagefehler
- Unsichere Dateikopie während Writes
- Defekte Synchronisation

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sqlite3 <datenbank.db> 'PRAGMA integrity_check;'
sqlite3 <datenbank.db> '.recover'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Originaldatei zuerst sichern.
- Integrity Check ausführen.
- Bei Korruption Recovery in neue Datenbank versuchen und Anwendung/Schema validieren.
- Storage-Ursache beheben.

## Weiterführende Prüfung

- Nicht auf Originaldatei experimentieren.
- Backups und Restore-Test etablieren.
