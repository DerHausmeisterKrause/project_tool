# SQLite: database is locked

## Symptom

Anwendung meldet `database is locked`.

## Bedeutung

Ein anderer Writer hält eine Sperre oder Transaktion bleibt zu lange offen.

## Typische Ursachen

- Lange Transaktion
- Mehrere Writer
- Prozess abgestürzt
- Netzwerkfilesystem ungeeignet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
lsof <datenbank.db>
sqlite3 <datenbank.db> 'PRAGMA journal_mode;'
sqlite3 <datenbank.db> 'PRAGMA busy_timeout;'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Schreibende Prozesse identifizieren.
- Transaktionen kurz halten.
- WAL-Modus kann je Workload helfen: `PRAGMA journal_mode=WAL;`.
- SQLite nicht als Mehrbenutzer-Server-DB auf ungeeignetem Network FS betreiben.

## Weiterführende Prüfung

- Backups vor manuellen Reparaturmaßnahmen erstellen.
- Anwendungskonflikte statt Lockdateien blind löschen.
