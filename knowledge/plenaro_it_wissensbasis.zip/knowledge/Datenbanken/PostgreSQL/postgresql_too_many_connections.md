# PostgreSQL: too many connections

## Symptom

Neue DB-Verbindungen scheitern mit `too many connections`.

## Bedeutung

`max_connections` ist erreicht oder Connection Pooling funktioniert nicht.

## Typische Ursachen

- Connection Leak
- Pool falsch dimensioniert
- Zu viele App-Instanzen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
psql -c "select count(*) from pg_stat_activity;"
psql -c "select usename,application_name,state,count(*) from pg_stat_activity group by 1,2,3 order by 4 desc;"
psql -c "show max_connections;"
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Verursachende Clients identifizieren.
- Connection Leak/Pool beheben.
- `max_connections` nur mit RAM-/Workload-Bewertung erhöhen.
- Connection Pooler erwägen.

## Weiterführende Prüfung

- Idle-in-transaction Sessions prüfen.
- Monitoring für aktive/idle Connections einrichten.
