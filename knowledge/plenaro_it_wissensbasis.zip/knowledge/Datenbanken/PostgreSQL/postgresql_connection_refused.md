# PostgreSQL: Connection refused

## Symptom

Client kann TCP-Verbindung zu PostgreSQL nicht aufbauen.

## Bedeutung

PostgreSQL lauscht nicht auf Zieladresse/Port oder Netzwerkzugriff wird aktiv abgelehnt.

## Typische Ursachen

- Dienst down
- listen_addresses falsch
- Port falsch
- Firewall

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
systemctl status postgresql
ss -tulpn | grep 5432
pg_isready -h <host> -p 5432
grep -R '^listen_addresses\|^port' /etc/postgresql/*/*/postgresql.conf
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Dienststatus und Listening prüfen.
- listen_addresses/port korrigieren.
- Firewall öffnen, falls fachlich erforderlich.
- Danach pg_hba.conf für Authentifizierung getrennt prüfen.

## Weiterführende Prüfung

- Cluster/Version über `pg_lsclusters` auf Debian/Ubuntu prüfen.
- Unix-Socket-Verbindung separat testen.
