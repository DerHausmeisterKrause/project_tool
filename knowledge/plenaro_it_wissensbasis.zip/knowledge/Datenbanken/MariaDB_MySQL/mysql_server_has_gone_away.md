# MySQL/MariaDB: server has gone away

## Symptom

Anwendung verliert DB-Verbindung und meldet `MySQL server has gone away`.

## Bedeutung

Verbindung wurde beendet, z. B. durch Timeout, Paketgröße, Restart oder Netzwerkproblem.

## Typische Ursachen

- wait_timeout
- max_allowed_packet
- DB-Restart
- Netzwerkabbruch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
SHOW VARIABLES LIKE 'wait_timeout';
SHOW VARIABLES LIKE 'max_allowed_packet';
SHOW GLOBAL STATUS LIKE 'Aborted_connects';
journalctl -u mariadb --since '-30 min'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Zeitpunkt mit DB-Logs abgleichen.
- Bei großen Queries/Paketen max_allowed_packet prüfen.
- Connection Pool/Reconnect-Logik kontrollieren.
- Restarts/OOM ausschließen.

## Weiterführende Prüfung

- Nicht automatisch nur Timeout erhöhen.
- Proxy/Load Balancer zwischen App und DB prüfen.
