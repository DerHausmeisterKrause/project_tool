# MariaDB/MySQL: Access denied

## Symptom

Client meldet `Access denied for user ...`.

## Bedeutung

Benutzer, Host-Muster, Passwort oder Authentifizierungsplugin passt nicht.

## Typische Ursachen

- Falsches Passwort
- User nur für anderen Host angelegt
- Plugin mismatch
- Grant fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
mysql -u <user> -p -h <host>
SELECT User,Host,plugin FROM mysql.user;
SHOW GRANTS FOR '<user>'@'<host>';
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exakten User@Host-Match prüfen.
- Passwort/Plugin passend konfigurieren.
- Benötigte Rechte minimal mit GRANT vergeben.

## Weiterführende Prüfung

- `localhost` und `127.0.0.1` können unterschiedliche Verbindungswege bedeuten.
- Keine globalen `%`-Hosts ohne Bedarf.
