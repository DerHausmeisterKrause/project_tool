# Datenbank: Langsame Queries

## Symptom

Anwendung reagiert langsam, DB-CPU/I/O steigt.

## Bedeutung

Fehlende Indizes, schlechte Query-Pläne, Locks oder Ressourcenengpässe erhöhen Latenz.

## Typische Ursachen

- Full Table Scan
- Fehlender Index
- Lock Waiting
- I/O-Limit
- Statistiken veraltet

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
PostgreSQL: EXPLAIN (ANALYZE, BUFFERS) <query>;
MySQL: EXPLAIN <query>;
DB-spezifische Slow Query Logs
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Langsame Query reproduzierbar identifizieren.
- Plan analysieren.
- Index nur passend zur Query/Workload ergänzen.
- Locks und I/O berücksichtigen.

## Weiterführende Prüfung

- EXPLAIN ANALYZE führt die Query aus; bei schreibenden/teuren Queries Vorsicht.
- Vorher/Nachher messen.
