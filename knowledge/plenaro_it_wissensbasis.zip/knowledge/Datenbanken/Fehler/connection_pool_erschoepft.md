# Datenbank-Connection-Pool erschöpft

## Symptom

Anwendung meldet keine freie Connection, obwohl DB selbst erreichbar ist.

## Bedeutung

Applikationspool hat alle Verbindungen belegt oder Leaks verhindern Rückgabe.

## Typische Ursachen

- Connection Leak
- Pool zu klein
- Langsame Queries
- DB-Verbindungen hängen

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
psql -c "select usename,application_name,state,count(*) from pg_stat_activity group by 1,2,3 order by 4 desc;"
DB Sessions/Connections nach application_name/user gruppieren
Thread-/Request-Dumps nach Plattform
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Leak und lang laufende DB-Operationen identifizieren.
- Poolgröße an DB-Grenzen und reale Parallelität anpassen.
- Timeouts/Max Lifetime sinnvoll setzen.

## Weiterführende Prüfung

- Pool nicht größer als DB verkraftet dimensionieren.
- Fehler unter Lasttest reproduzieren.
