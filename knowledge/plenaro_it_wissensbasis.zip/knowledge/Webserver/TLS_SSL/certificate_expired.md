# TLS-Zertifikat abgelaufen

## Symptom

Browser/Client meldet abgelaufenes Zertifikat.

## Bedeutung

NotAfter-Datum des Serverzertifikats liegt in der Vergangenheit oder Systemzeit ist falsch.

## Typische Ursachen

- Renewal fehlgeschlagen
- Falsches Zertifikat ausgeliefert
- Zeit falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
date -Is
openssl s_client -connect <host>:443 -servername <host> </dev/null 2>/dev/null | openssl x509 -noout -dates -subject -issuer
curl -Iv https://<host>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Systemzeit prüfen.
- Richtiges Zertifikat erneuern und Webserver reloaden.
- SNI/vHost kontrollieren, wenn trotz Erneuerung altes Zertifikat erscheint.

## Weiterführende Prüfung

- Automatische Renewal-Jobs und Monitoring prüfen.
- Zertifikatskette nach Renewal validieren.
