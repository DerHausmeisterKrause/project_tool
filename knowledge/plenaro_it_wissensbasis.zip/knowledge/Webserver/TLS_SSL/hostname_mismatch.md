# TLS: Hostname mismatch

## Symptom

Client meldet, dass Zertifikat nicht für den aufgerufenen Namen gültig ist.

## Bedeutung

Der DNS-Name fehlt in den Subject Alternative Names (SAN) des Zertifikats.

## Typische Ursachen

- Falsches Zertifikat
- Falscher vHost/SNI
- Aufruf über Alias/IP nicht im SAN

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
openssl s_client -connect <host>:443 -servername <host> </dev/null 2>/dev/null | openssl x509 -noout -ext subjectAltName
curl -Iv https://<host>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Passendes Zertifikat mit benötigten SAN-Namen bereitstellen.
- SNI/vHost-Zuordnung korrigieren.
- Nicht die Zertifikatsprüfung deaktivieren.

## Weiterführende Prüfung

- CNAME allein macht Zertifikat nicht automatisch gültig.
- Interne/externe Namen getrennt berücksichtigen.
