# TLS: Unknown CA / unvollständige Zertifikatskette

## Symptom

Client vertraut dem Serverzertifikat nicht oder meldet unable to get local issuer certificate.

## Bedeutung

Root CA fehlt im Client-Truststore oder Server liefert Intermediate-Zertifikate nicht vollständig.

## Typische Ursachen

- Intermediate fehlt
- Interne CA nicht verteilt
- Falsches fullchain-File

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
openssl s_client -connect <host>:443 -servername <host> -showcerts
curl -Iv https://<host>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Server muss Zertifikat plus notwendige Intermediates ausliefern.
- Bei interner PKI Root/Intermediate CA kontrolliert auf Clients verteilen.
- Webserver auf korrektes fullchain-Zertifikat konfigurieren.

## Weiterführende Prüfung

- Root CA wird normalerweise nicht vom Server mitgeliefert.
- Mehrere Clientplattformen testen.
