# Apache HTTP 500 Internal Server Error

## Symptom

Webseite liefert 500, Apache selbst läuft.

## Bedeutung

Anwendung, Modul, Rewrite-Regel oder Backend erzeugt internen Serverfehler.

## Typische Ursachen

- PHP/App-Exception
- Falsche .htaccess-Direktive
- CGI/FastCGI-Problem
- Dateirechte

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
tail -n 100 /var/log/apache2/error.log
apachectl configtest
curl -v http://127.0.0.1/<pfad>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Error Log zum Request-Zeitpunkt prüfen.
- Anwendungslog parallel auswerten.
- Fehlerhafte Rewrite-/Proxy-/PHP-Konfiguration beheben.
- Keine Debug-Stacktraces öffentlich ausgeben.

## Weiterführende Prüfung

- Request-ID/Korrelation verwenden, falls vorhanden.
- Berechtigungen und Backendstatus prüfen.
