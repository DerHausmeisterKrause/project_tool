# Apache-Konfigurationstest schlägt fehl

## Symptom

Apache startet/reloadet nicht; `apachectl configtest` meldet Fehler.

## Bedeutung

Eine Direktive, ein Modul, Zertifikat oder Include ist fehlerhaft.

## Typische Ursachen

- Syntaxfehler
- Modul nicht geladen
- Doppelter Listen-Port
- Datei fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
apachectl configtest
apachectl -S
apachectl -M
journalctl -u apache2 -b
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Fehlerzeile aus configtest korrigieren.
- Benötigtes Modul prüfen.
- VirtualHost-/Listen-Konflikte mit `apachectl -S` untersuchen.
- Danach kontrolliert reloaden.

## Weiterführende Prüfung

- Unter RHEL kann Dienst `httpd` heißen.
- Includes und Symlinks in sites-enabled prüfen.
