# HTTP 504 Gateway Timeout

## Symptom

Reverse Proxy oder Gateway liefert 504.

## Bedeutung

Upstream hat innerhalb des konfigurierten Zeitlimits nicht rechtzeitig geantwortet.

## Typische Ursachen

- Langsame Anwendung
- DB hängt
- Upstream-Netzwerkproblem
- Timeout zu knapp

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
curl -v http://<upstream>:<port>/
ss -tulpn
tail -n 100 /var/log/nginx/error.log
journalctl -u <backend> --since '-10 min'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Upstream-Latenz direkt messen.
- Anwendungs-/DB-Ursache beheben.
- Timeout nur erhöhen, wenn die längere Antwortzeit fachlich erwartet und akzeptabel ist.

## Weiterführende Prüfung

- 502 und 504 unterscheiden.
- Load-Balancer-/Proxy-Kaskaden prüfen.
