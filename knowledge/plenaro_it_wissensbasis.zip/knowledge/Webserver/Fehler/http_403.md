# HTTP 403 Forbidden

## Symptom

Webserver antwortet mit 403.

## Bedeutung

Server versteht die Anfrage, verweigert aber den Zugriff.

## Typische Ursachen

- Datei-/Verzeichnisrechte
- Webserver allow/deny-Regel
- Authz-Regel
- WAF

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
curl -v https://<host>/<pfad>
namei -l <docroot>/<pfad>
nginx -T
apachectl -S
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Webserver-Errorlog lesen.
- Filesystem-Rechte und Webserver-Regeln prüfen.
- WAF/Access-Control nur gezielt anpassen.

## Weiterführende Prüfung

- 403 von Anwendung und 403 vom Webserver unterscheiden.
- Index-/Directory-Regeln prüfen.
