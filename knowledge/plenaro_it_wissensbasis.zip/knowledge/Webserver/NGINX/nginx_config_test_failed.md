# NGINX-Konfigurationstest schlägt fehl

## Symptom

`nginx -t` meldet Syntaxfehler oder unbekannte Direktive.

## Bedeutung

NGINX kann die Konfiguration nicht laden.

## Typische Ursachen

- Syntaxfehler
- Direktive im falschen Kontext
- Modul fehlt
- Datei/Include fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nginx -t
nginx -T
journalctl -u nginx -b
nginx -V
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Exakte Datei und Zeile aus `nginx -t` korrigieren.
- Bei unknown directive prüfen, ob das benötigte Modul kompiliert/geladen ist.
- Erst nach erfolgreichem Test reloaden: `systemctl reload nginx`.

## Weiterführende Prüfung

- Includes mit `nginx -T` prüfen.
- Distribution-spezifische Modul-Pakete berücksichtigen.
