# NGINX 502 Bad Gateway

## Symptom

Client erhält HTTP 502 von NGINX Reverse Proxy.

## Bedeutung

NGINX kann keine gültige Antwort vom Upstream erhalten.

## Typische Ursachen

- Upstream down
- Falscher Host/Port
- Unix-Socket-Rechte
- TLS zum Upstream fehlerhaft

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nginx -t
tail -n 100 /var/log/nginx/error.log
ss -tulpn
curl -v http://<upstream>:<port>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Upstream direkt vom NGINX-Host testen.
- proxy_pass-Ziel prüfen.
- Dienststatus und Port kontrollieren.
- Bei Unix-Sockets Benutzer-/Gruppenrechte prüfen.

## Weiterführende Prüfung

- Timeout vs. Connection refused unterscheiden.
- SELinux/AppArmor bei korrekten Unix-Rechten berücksichtigen.
