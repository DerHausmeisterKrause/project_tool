# Reverse Proxy: WebSocket funktioniert nicht

## Symptom

Normale HTTP-Aufrufe funktionieren, WebSocket-Verbindung bricht ab.

## Bedeutung

Upgrade-/Connection-Header oder Proxy-/Idle-Timeouts sind falsch.

## Typische Ursachen

- Upgrade Header fehlt
- HTTP-Version ungeeignet
- Proxy Timeout
- Backend-Pfad falsch

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
curl -I https://<host>/
nginx -T | grep -n -E 'Upgrade|proxy_http_version|proxy_read_timeout'
tail -n 100 /var/log/nginx/error.log
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Für NGINX bei Bedarf `proxy_http_version 1.1` und passende Upgrade-/Connection-Header konfigurieren.
- Backend-WebSocket-Endpunkt prüfen.
- Timeouts passend zur Anwendung setzen.

## Weiterführende Prüfung

- Nicht jede WebSocket-App benötigt identische Pfade.
- Load Balancer davor ebenfalls prüfen.
