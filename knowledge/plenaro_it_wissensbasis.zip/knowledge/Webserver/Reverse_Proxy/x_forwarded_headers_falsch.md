# Reverse Proxy: X-Forwarded-Header falsch

## Symptom

Anwendung erzeugt falsche Redirects, falsches Schema oder protokolliert Proxy-IP statt Client-IP.

## Bedeutung

Forwarded-Header werden nicht gesetzt oder Anwendung vertraut ihnen nicht korrekt.

## Typische Ursachen

- X-Forwarded-Proto fehlt
- X-Forwarded-For falsch
- Trusted Proxy nicht konfiguriert

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
nginx -T | grep -n 'proxy_set_header'
curl -I https://<host>/
tail -n 100 /var/log/nginx/access.log
tail -n 100 /var/log/nginx/error.log
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Typisch `Host`, `X-Real-IP`, `X-Forwarded-For` und `X-Forwarded-Proto` passend setzen.
- Anwendung nur vertrauenswürdigen Reverse Proxies erlauben, diese Header zu beeinflussen.

## Weiterführende Prüfung

- Header-Spoofing verhindern.
- Bei mehreren Proxies Kette korrekt behandeln.
