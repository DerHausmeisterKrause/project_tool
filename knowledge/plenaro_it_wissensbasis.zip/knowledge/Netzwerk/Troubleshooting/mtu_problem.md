# MTU-/Fragmentierungsproblem

## Symptom

Kleine Pings oder Verbindungen funktionieren, große Transfers/TLS hängen oder brechen ab.

## Bedeutung

Pakete sind für einen Pfad zu groß und PMTUD/Fragmentierung funktioniert nicht korrekt.

## Typische Ursachen

- VPN/Tunnel reduziert MTU
- ICMP Fragmentation Needed blockiert
- Falsche Interface-MTU

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip link show
ping -M do -s 1472 <ziel>  # IPv4-Test, Größe anpassen
tracepath <ziel>
netsh interface ipv4 show subinterfaces
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Maximal funktionierende Paketgröße ermitteln.
- MTU am Tunnel/Interface korrekt setzen.
- Benötigte ICMP-Meldungen nicht pauschal blockieren.

## Weiterführende Prüfung

- IPv6 benötigt funktionierende ICMPv6-Meldungen.
- MSS Clamping nur gezielt einsetzen.
