# Schichtweises Netzwerk-Troubleshooting

## Symptom

Unklarer Netzwerkfehler ohne eindeutige Ursache.

## Bedeutung

Ein strukturiertes Vorgehen trennt Link, IP, Routing, DNS, Transport und Anwendung.

## Typische Ursachen

- Link down
- Falsche IP/VLAN
- Routing
- DNS
- Firewall/Port
- Anwendung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip link
Get-NetAdapter
ip a
ipconfig /all
ip r
route print
ping <gateway>
dig <name>
Resolve-DnsName <name>
nc -vz <host> <port>
Test-NetConnection <host> -Port <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Zuerst lokale Schnittstelle und Adresse prüfen.
- Dann Gateway/Routing.
- Danach DNS.
- Anschließend Zielport und erst danach Anwendung.

## Weiterführende Prüfung

- Nicht mit DNS beginnen, wenn schon das Gateway unerreichbar ist.
- Fehlerzeit und betroffene Richtung dokumentieren.
