# Wichtige Standardports

## Symptom

Schnelle Referenz für typische Infrastrukturports.

## Bedeutung

Ports helfen beim Troubleshooting, ersetzen aber nicht die Prüfung der tatsächlich konfigurierten Anwendung.

## Typische Ursachen

- HTTP 80/TCP
- HTTPS 443/TCP
- SSH 22/TCP
- DNS 53/UDP und 53/TCP
- DHCP 67/68 UDP
- RDP 3389/TCP/UDP
- SMB 445/TCP
- LDAP 389/TCP/UDP, LDAPS 636/TCP
- NTP 123/UDP

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
netstat -ano
Test-NetConnection <host> -Port <port>
nc -vz <host> <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Immer den real konfigurierten Port der Anwendung prüfen.
- Firewallregeln möglichst dienstbezogen und minimal halten.

## Weiterführende Prüfung

- Einige Protokolle nutzen dynamische Zusatzports, z. B. RPC.
- TLS kann auf anderen Ports betrieben werden.
