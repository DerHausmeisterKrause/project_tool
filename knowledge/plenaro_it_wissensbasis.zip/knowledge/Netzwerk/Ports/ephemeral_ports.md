# Ephemeral Ports / dynamische Clientports

## Symptom

Verbindungen nutzen auf Clientseite wechselnde hohe Quellports.

## Bedeutung

Betriebssysteme vergeben dynamische Quellports für ausgehende Verbindungen; manche Serverprotokolle nutzen zusätzlich dynamische Ports.

## Typische Ursachen

- Stateful Firewall erwartet Rückverkehr
- RPC nutzt dynamische Ports
- Porterschöpfung bei hoher Last

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
netsh int ipv4 show dynamicport tcp
cat /proc/sys/net/ipv4/ip_local_port_range
ss -s
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Nicht nur den Client-Quellport statisch freigeben.
- Stateful Regeln korrekt einsetzen.
- Bei RPC notwendige dynamische Bereiche oder eingeschränkte RPC-Konfiguration berücksichtigen.

## Weiterführende Prüfung

- NAT-Tabellen und Connection Tracking bei hoher Last prüfen.
- TIME_WAIT nicht pauschal als Fehler interpretieren.
