# UDP-Troubleshooting

## Symptom

UDP-Anwendung funktioniert nicht, obwohl kein klarer Verbindungsfehler angezeigt wird.

## Bedeutung

UDP hat keinen Handshake; Erfolg muss über Anwendung, Antwortpakete oder Mitschnitt bewertet werden.

## Typische Ursachen

- Firewall blockiert
- Server lauscht nicht
- Antwortroute fehlt
- Anwendungsprotokoll fehlerhaft

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -ulpn
nc -u -v <host> <port>
tcpdump -nn -i any udp port <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Serverseitiges Listening prüfen.
- Pakete beidseitig mitschneiden.
- Firewallregeln und Rückweg prüfen.
- Anwendungsprotokoll berücksichtigen.

## Weiterführende Prüfung

- `nc -u` beweist ohne Antwort nicht zwingend, dass der Dienst funktioniert.
- ICMP Port Unreachable beachten.
