# TCP 3-Way-Handshake scheitert

## Symptom

SYN wird gesendet, aber Verbindung kommt nicht zustande.

## Bedeutung

SYN-ACK fehlt oder wird nicht bestätigt.

## Typische Ursachen

- Firewall DROP
- Dienst nicht erreichbar
- Rückroute fehlt
- RST durch Ziel

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
tcpdump -nn -i <if> tcp port <port>
ss -tn state syn-sent
nc -vz <host> <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Paketmitschnitt auf Client und Server vergleichen.
- Bei RST Dienst/Port prüfen.
- Bei fehlender Antwort Firewall/Routing untersuchen.

## Weiterführende Prüfung

- SYN retransmissions beachten.
- MSS/MTU bei VPN-Verbindungen prüfen.
