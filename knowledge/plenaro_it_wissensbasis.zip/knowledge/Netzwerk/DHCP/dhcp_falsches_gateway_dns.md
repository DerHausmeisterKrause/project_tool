# DHCP liefert falsches Gateway oder DNS

## Symptom

Clients erhalten Lease, aber Routing oder Namensauflösung funktioniert nicht.

## Bedeutung

DHCP-Optionen enthalten falsche Werte.

## Typische Ursachen

- Option 003 Router falsch
- Option 006 DNS falsch
- Falscher Scope/VLAN
- Alte Lease

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ipconfig /all
nmcli dev show 2>/dev/null
ip r
cat /etc/resolv.conf
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- DHCP-Scope-Optionen korrigieren.
- Lease erneuern.
- VLAN/Scope-Zuordnung validieren.

## Weiterführende Prüfung

- Reservations/Policy-basierte DHCP-Optionen prüfen.
- VPN-Adapter können DNS/Gateway überlagern.
