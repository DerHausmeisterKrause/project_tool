# DHCP: Client erhält keine IP-Adresse

## Symptom

Client erhält APIPA/169.254.x.x oder keine Lease.

## Bedeutung

DHCP Discover/Offer/Request/Ack wird nicht vollständig ausgetauscht.

## Typische Ursachen

- DHCP-Server nicht erreichbar
- Scope erschöpft
- VLAN/Relay falsch
- UDP 67/68 blockiert

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ipconfig /all
ipconfig /renew
tcpdump -ni <if> 'port 67 or port 68'
show-ähnliche Befehle am DHCP-Server je Produkt
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Scope-Auslastung prüfen.
- DHCP Relay/IP Helper für Client-VLAN prüfen.
- VLAN-Zuordnung und Firewall prüfen.
- Serverdienst und Bindings kontrollieren.

## Weiterführende Prüfung

- DORA-Paketfolge im Mitschnitt prüfen.
- Rogue-DHCP ausschließen.
