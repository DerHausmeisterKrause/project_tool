# Asymmetrisches Routing

## Symptom

Verbindungen brechen trotz scheinbar korrekter Hinroute ab; Stateful Firewall verwirft Antworten.

## Bedeutung

Hin- und Rückverkehr nehmen unterschiedliche Pfade, die nicht mit Stateful Inspection/NAT kompatibel sind.

## Typische Ursachen

- Mehrere Gateways
- Policy Routing
- Fehlende Rückroute
- ECMP/NAT

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
traceroute <ziel>
traceroute von Gegenrichtung
ip route get <ziel>
tcpdump -ni any host <ziel>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Hin- und Rückroute dokumentieren.
- Rückrouten ergänzen oder Routing-Policy korrigieren.
- Stateful Firewall/NAT-Pfad konsistent halten.

## Weiterführende Prüfung

- Reverse Path Filtering bei Linux prüfen.
- Load Balancer/NAT-Gateways in Pfad aufnehmen.
