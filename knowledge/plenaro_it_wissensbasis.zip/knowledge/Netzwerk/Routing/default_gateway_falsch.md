# Falsches Default Gateway

## Symptom

Lokales Netz funktioniert, entfernte Netze/Internet nicht.

## Bedeutung

Default Route zeigt auf falschen oder nicht erreichbaren Next Hop.

## Typische Ursachen

- DHCP-Option falsch
- Statische Route falsch
- Mehrere Gateways mit Metrikproblem

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip route
route print
tracert <ziel>
traceroute <ziel>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Default Route und Interface prüfen.
- Falschen Gateway-Eintrag korrigieren.
- Bei mehreren Uplinks Metriken/Policy Routing bewusst konfigurieren.

## Weiterführende Prüfung

- Rückroute auf Gegenstelle prüfen.
- VPN-Routen berücksichtigen.
