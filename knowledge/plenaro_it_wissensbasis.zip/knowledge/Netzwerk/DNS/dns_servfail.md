# DNS: SERVFAIL

## Symptom

DNS-Abfrage liefert SERVFAIL.

## Bedeutung

Der Resolver konnte die Anfrage nicht erfolgreich verarbeiten.

## Typische Ursachen

- DNSSEC-Fehler
- Upstream nicht erreichbar
- Autoritative Server fehlerhaft
- Resolverproblem

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
dig <name>
dig <name> +dnssec
dig @<resolver> <name>
dig +trace <name>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Mit anderem Resolver und direkt gegen autoritative Server vergleichen.
- DNSSEC und Upstream-Erreichbarkeit prüfen.
- Resolverlogs auswerten.

## Weiterführende Prüfung

- Zeitprobleme können DNSSEC beeinflussen.
- SERVFAIL ist nicht gleich 'Record fehlt'.
