# DNS: NXDOMAIN

## Symptom

DNS-Abfrage liefert NXDOMAIN.

## Bedeutung

Der autoritative DNS-Namensraum meldet, dass der Name nicht existiert.

## Typische Ursachen

- Record fehlt
- Falscher DNS-Suffix
- Split-DNS falsch
- Negative Cache-Eintrag

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
dig <name>
dig +trace <name>
nslookup <name>
resolvectl query <name>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- FQDN prüfen.
- Autoritative Zone/Record kontrollieren.
- Bei Split-DNS richtigen Resolver verwenden.
- Negative TTL beachten.

## Weiterführende Prüfung

- Nicht mit SERVFAIL verwechseln.
- Bei AD interne Zone und Replikation prüfen.
