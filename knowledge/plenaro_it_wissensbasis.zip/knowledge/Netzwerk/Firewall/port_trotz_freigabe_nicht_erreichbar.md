# Port trotz Firewall-Freigabe nicht erreichbar

## Symptom

Regel ist vorhanden, Verbindung auf Port scheitert trotzdem.

## Bedeutung

Häufig lauscht der Dienst nicht, falsches Interface/Protokoll wurde freigegeben oder eine weitere Firewall blockiert.

## Typische Ursachen

- Dienst lauscht nicht
- TCP/UDP verwechselt
- Host-Firewall plus Netzfirewall
- NAT fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
Test-NetConnection <host> -Port <port>
nc -vz <host> <port>
tcpdump -ni any port <port>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Am Ziel mit ss prüfen.
- Paketfluss an Firewall und Ziel mitschneiden.
- Regelrichtung, Zone, Interface und Protokoll prüfen.
- NAT/Port Forwarding bei eingehenden Verbindungen kontrollieren.

## Weiterführende Prüfung

- Rule hit counters auswerten.
- Rückweg und lokale Host-Firewall prüfen.
