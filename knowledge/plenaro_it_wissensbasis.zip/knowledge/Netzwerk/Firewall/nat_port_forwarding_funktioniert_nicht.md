# NAT / Port Forwarding funktioniert nicht

## Symptom

Externer Zugriff auf weitergeleiteten Port erreicht internen Dienst nicht.

## Bedeutung

DNAT-Regel, Filterregel, Hairpin-NAT oder Rückroute ist unvollständig.

## Typische Ursachen

- Falsche Ziel-IP/Port
- Firewallregel fehlt
- Dienst bindet nur localhost
- Rückroute/NAT fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
tcpdump -ni <wan> port <port>
tcpdump -ni <lan> host <ziel>
curl -v http://<ziel>:<port>/
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Internen Dienst zuerst lokal testen.
- DNAT und Filterregel prüfen.
- Rückweg sicherstellen.
- Hairpin-Zugriff getrennt von externem Zugriff testen.

## Weiterführende Prüfung

- Carrier Grade NAT beim ISP ausschließen.
- IPv6 separat betrachten.
