# VLAN: Client hat keine Verbindung

## Symptom

Gerät im VLAN erreicht Gateway oder andere Netze nicht.

## Bedeutung

Access-/Trunk-Konfiguration, Tagging oder Layer-3-Interface passt nicht zusammen.

## Typische Ursachen

- Falsche PVID/Access VLAN
- VLAN nicht auf Trunk erlaubt
- Native VLAN mismatch
- SVI/Gateway fehlt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip a
ip r
ping <gateway>
tcpdump -eni <if> vlan
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Switchport-Rolle prüfen.
- VLAN auf allen Trunks zulassen.
- Gateway/SVI und DHCP für das VLAN prüfen.
- Tagging nur dort aktivieren, wo Endpoint es erwartet.

## Weiterführende Prüfung

- STP/Port-Security prüfen.
- MAC-Tabelle und ARP/Neighbor-Tabelle kontrollieren.
