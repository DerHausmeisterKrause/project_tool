# VLAN fehlt auf einem Trunk

## Symptom

Ein bestimmtes VLAN funktioniert hinter einem Switch/Uplink nicht, andere VLANs schon.

## Bedeutung

Das VLAN ist auf mindestens einem Trunk nicht erlaubt oder nicht vorhanden.

## Typische Ursachen

- Allowed VLAN List unvollständig
- VLAN lokal nicht angelegt
- LAG-Mitglied inkonsistent

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ip -d link show
ping <gateway>
arp -a
ip neigh
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- VLAN end-to-end auf jedem Uplink prüfen.
- Allowed-Liste und VLAN-Existenz korrigieren.
- Bei Port-Channel/LAG konsistente Konfiguration sicherstellen.

## Weiterführende Prüfung

- MAC-Learning pro VLAN verfolgen.
- Native VLAN nicht unnötig ändern.
