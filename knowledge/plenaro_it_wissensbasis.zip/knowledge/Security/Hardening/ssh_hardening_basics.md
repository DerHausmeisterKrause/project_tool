# SSH Hardening – Grundlagen

## Symptom

SSH soll gegen unnötige Angriffsfläche gehärtet werden.

## Bedeutung

Sichere Defaults reduzieren Passwortangriffe und privilegierte Direktanmeldung.

## Typische Ursachen

- Root-Login erlaubt
- Passwortauthentifizierung unnötig aktiv
- Zu breite Benutzerfreigabe

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
sshd -T
sshd -t
journalctl -u ssh -b
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Key-basierte Authentifizierung verwenden, wenn organisatorisch möglich.
- `PermitRootLogin no` setzen, wenn kein direkter Root-Login benötigt wird.
- Zugriff über AllowUsers/AllowGroups einschränken, wenn sinnvoll.
- Vor Reload immer `sshd -t` testen und bestehende Sitzung offen halten.

## Weiterführende Prüfung

- MFA/Bastion/Teleport je Umgebung erwägen.
- Portänderung ersetzt keine echte Härtung.
