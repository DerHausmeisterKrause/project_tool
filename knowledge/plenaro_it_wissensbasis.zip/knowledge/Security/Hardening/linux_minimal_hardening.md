# Linux Server – Minimal-Hardening

## Symptom

Neuer Linux-Server soll mit einer sicheren Basis betrieben werden.

## Bedeutung

Patchstand, minimale Dienste, Firewall, SSH, Logging und Backups sind Kernmaßnahmen.

## Typische Ursachen

- Unnötige Pakete/Dienste
- Offene Ports
- Veraltete Updates
- Schwache Adminzugänge

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ss -tulpn
systemctl --type=service --state=running
apt list --upgradable
ufw status verbose 2>/dev/null || nft list ruleset
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- System aktualisieren.
- Nur benötigte Dienste betreiben.
- Firewall mit dokumentierten Regeln aktivieren.
- SSH absichern.
- Zeit, Logging, Monitoring und getestete Backups einrichten.

## Weiterführende Prüfung

- Härtung gegen Betriebsanforderungen testen.
- Automatisierung/Configuration Management für Reproduzierbarkeit verwenden.
