# Warum chmod 777 vermeiden

## Symptom

Ein Berechtigungsproblem wird durch `chmod -R 777` scheinbar gelöst.

## Bedeutung

777 erlaubt jedem lokalen Benutzer Schreiben/Ausführen und kaschiert die eigentliche Ownership-/Gruppenursache.

## Typische Ursachen

- Falscher Owner
- Fehlende Gruppe
- Deployment setzt falsche Umask

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ls -la <pfad>
namei -l <pfad>
getfacl <pfad>
id <dienstuser>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Benötigten Dienstbenutzer und Gruppe bestimmen.
- Owner/Group mit chown/chgrp korrigieren.
- Mode-Bits oder ACL minimal setzen.

## Weiterführende Prüfung

- Secrets und Private Keys besonders restriktiv halten.
- Rekursive Rechteänderungen nur nach vorheriger Prüfung.
