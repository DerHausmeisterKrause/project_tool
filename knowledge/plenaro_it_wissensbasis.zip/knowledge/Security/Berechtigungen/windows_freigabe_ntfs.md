# Windows Freigabe- und NTFS-Berechtigungen

## Symptom

Benutzer hat trotz Freigaberecht Zugriff verweigert oder unerwartet zu viele Rechte.

## Bedeutung

Bei SMB wirken Freigabe- und NTFS-Berechtigungen zusammen; effektiv greift die restriktivere Kombination.

## Typische Ursachen

- Gruppenmitgliedschaft
- Explizites Deny
- Freigaberechte
- NTFS-Vererbung

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
icacls <pfad>
Get-SmbShareAccess -Name <share>
whoami /groups
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Effektive Gruppenmitgliedschaften prüfen.
- Share- und NTFS-Rechte getrennt dokumentieren.
- Rechte bevorzugt über Gruppen vergeben.
- Explizite Deny-Regeln sparsam nutzen.

## Weiterführende Prüfung

- Anmeldetoken nach Gruppenänderung erneuern.
- Access-Based Enumeration nicht mit Berechtigungen verwechseln.
