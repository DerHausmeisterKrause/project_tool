# Fail2ban blockiert legitimen Client

## Symptom

Ein legitimer Host erreicht SSH/Webdienst plötzlich nicht mehr.

## Bedeutung

Fail2ban hat aufgrund passender Fehlversuche eine Ban-Regel gesetzt.

## Typische Ursachen

- Falsche Passwörter
- Scanner/NAT teilt Quell-IP
- Filter zu aggressiv

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
fail2ban-client status
fail2ban-client status <jail>
journalctl -u fail2ban --since '-1 hour'
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Ban-Ursache und Jail prüfen.
- Bei berechtigtem Fall gezielt unbannen: `fail2ban-client set <jail> unbanip <ip>`.
- Filter/Retry-Werte nur begründet anpassen.

## Weiterführende Prüfung

- Whitelists sparsam einsetzen.
- Bei NAT mehrere Benutzer hinter einer IP berücksichtigen.
