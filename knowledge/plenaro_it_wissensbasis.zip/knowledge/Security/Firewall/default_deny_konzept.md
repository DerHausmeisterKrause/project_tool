# Firewall Default Deny

## Symptom

Neue Verbindungen funktionieren nach Härtung nicht.

## Bedeutung

Bei Default-Deny ist nur explizit erlaubter Verkehr zulässig.

## Typische Ursachen

- Fehlende Regel
- Falsche Richtung
- Falsches Interface/Zone
- Rückverkehr nicht stateful erlaubt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
ufw status verbose
nft list ruleset
iptables -S
Windows: Get-NetFirewallProfile; Get-NetFirewallRule
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Benötigte Flows dokumentieren: Quelle, Ziel, Protokoll, Port, Richtung.
- Minimal notwendige Regeln setzen.
- Logs/Counter zur Verifikation nutzen.

## Weiterführende Prüfung

- Managementzugang vor Remote-Härtung absichern.
- IPv4 und IPv6 berücksichtigen.
