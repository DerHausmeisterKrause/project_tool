# Privater Schlüssel passt nicht zum Zertifikat

## Symptom

Webserver startet nach Zertifikatswechsel nicht oder meldet key mismatch.

## Bedeutung

Public Key im Zertifikat gehört nicht zum konfigurierten Private Key.

## Typische Ursachen

- Falsche Key-Datei
- Zertifikat aus anderer CSR
- Deployment verwechselt Dateien

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
openssl x509 -in cert.pem -pubkey -noout | sha256sum
openssl pkey -in key.pem -pubout | sha256sum
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Hashes der Public Keys vergleichen.
- Passenden Private Key verwenden oder neues Zertifikat mit korrektem Key ausstellen.
- Private Keys nicht unnötig kopieren.

## Weiterführende Prüfung

- Dateirechte des Keys restriktiv halten.
- Bei PKCS#12 zuerst Inhalt kontrolliert extrahieren.
