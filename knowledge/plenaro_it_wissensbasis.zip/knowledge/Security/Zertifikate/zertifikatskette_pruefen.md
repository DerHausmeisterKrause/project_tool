# Zertifikatskette prüfen

## Symptom

TLS-Clients melden Vertrauensfehler oder unterschiedliche Clients verhalten sich verschieden.

## Bedeutung

Zertifikatskette muss vom Serverzertifikat über Intermediates zu einer vertrauenswürdigen Root CA führen.

## Typische Ursachen

- Intermediate fehlt
- Falsche Chain
- Root nicht vertraut
- Cross-Signing-Effekt

## Diagnose

Zuerst den Fehler reproduzierbar eingrenzen und Zeitpunkt, betroffene Systeme sowie letzte Änderungen notieren.

## Befehle

```text
openssl s_client -connect <host>:443 -servername <host> -showcerts
openssl verify -CAfile <ca.pem> <cert.pem>
```

> Platzhalter wie `<host>`, `<dienst>`, `<port>`, `<pfad>` oder `<user>` vor Ausführung durch echte Werte ersetzen.

## Lösung

- Ausgelieferte Chain prüfen.
- Intermediates korrekt konfigurieren.
- Root CA im Client-Truststore nur installieren, wenn sie organisatorisch vertrauenswürdig ist.

## Weiterführende Prüfung

- Browser und OpenSSL können unterschiedliche Truststores verwenden.
- AIA-Fetching nicht als Serverkonfiguration voraussetzen.
